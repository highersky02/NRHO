
%第一步主程遍历随机搜索合适解程序

clc; clear; close all; clear path;
 global aux 
 
global lb ub
aux = get_NRHO();
t_star=4.3438*24*3600;
aux = get_NRHO();
dvMag = aux.dvMag;
calNum = 2*1e5;
% 结果预分配
hold on;
plot3(1-0.01215,0,0,'*');
resultMtx = cell(calNum , 1);
for iLoop = 1 : calNum 
        
       [thetas , xxf , sigma,op] = Bcr4bp_RandDI2D2( 1 , [dvMag , dvMag] , aux);
       
       tauf = thetas / -0.925195985520347;
           % -------------------------------- 步骤1：近月点 -> WSB --------------------------------
   
         options = odeset('RelTol' , 1e-12 , 'AbsTol' , 1e-12 , 'Events' , @Bcr4bp_EventEMRot2DEarthRp);
        [seg1_tt , seg1_xx ] = ode113(@vdp1, ...
            [tauf , tauf-150*86400 / t_star] , xxf , options );
       
        %plot3(seg1_xx(:,1),seg1_xx(:,2),seg1_xx(:,3));hold on;plot3(-0.01215,0,0,'*');

    %     % 【测试】
    %     plotOrb2D(seg1_xx , 'b' , 2)

    % -------------------------------- 步骤2：WSB -> 近地点 --------------------------------
 miu=0.01215;

   distance_from_target1 = norm([seg1_xx(end,1), seg1_xx(end,2), seg1_xx(end,3)] - [-miu,0, 0]);  
% 和P1距离条件（3 - 5倍地月距）
   distance_from_target2 = norm([seg1_xx(end,1), seg1_xx(end,2), seg1_xx(end,3)] - [1-miu, 0, 0]);  
if distance_from_target2-0.0057<0
    
    continue;
end
   if distance_from_target1 - 0.02>0
         continue;
end
%% --------------- 满足所有约束条件 ---------------
 
disp('1');
    %     % 【测试】
    %     % 【EMRot轨道】
    %     Bcr4bp_ScnEMRot(seg1_tt(1) , aux);
    %     plotOrb2D(seg1_xx , 'b' , 2);
    %     plotOrb2D(seg2_xx , 'r' , 2);
    %
    %     % 【SB1Rot轨道】
    %     [tt1_SB1Rot , xx1_SB1Rot] = Bcr4bp_EMRot2SB1RotMtx2D(seg1_tt , seg1_xx , aux);
    %     [tt2_SB1Rot , xx2_SB1Rot] = Bcr4bp_EMRot2SB1RotMtx2D(seg2_tt , seg2_xx , aux);
    %     Bcr4bp_ScnSB1Rot(tt1_SB1Rot(1) , aux);
    %     plotOrb2D(xx1_SB1Rot , 'b' , 2);
    %     plotOrb2D(xx2_SB1Rot , 'r' , 2);
ub = [1,0.1,2*3.1416, seg1_tt(end)-1 ];      % 上界  
lb = [0,-0.1,0, seg1_tt(end)-2];  % 下界 
x0=[];
x0=[sigma,op,thetas,seg1_tt(end)-1.1];
 
x=[];distances=[];
%%
x=ffmincon(x0);
%%
t_star=4.3438*24*3600;

 miu=0.01215;
    t_star=4.3438*24*3600;
    tauf =x(3) / -0.925195985520347;
        sigma = x(1);
    % dro入轨点状态 (LU , VU)
    periOrb_x = interp1(aux.periOrb_tt , aux.periOrb_xx , sigma * aux.periOrb_P , 'spline')';
    x_nrho = periOrb_x(1,1);
    y_nrho = periOrb_x(2,1);
    z_nrho = periOrb_x(3,1);
    vx_nrho = periOrb_x(4,1);
    vy_nrho = periOrb_x(5,1);
    vz_nrho = periOrb_x(6,1);
target_point = [-miu, 0, 0]; 
    % 计算卫星入轨状态
   xx_rot = [x_nrho ;y_nrho ;z_nrho;vx_nrho+x(2)*vx_nrho/sqrt(vx_nrho^2+vy_nrho^2+vz_nrho^2);vy_nrho+x(2)*vy_nrho/sqrt(vx_nrho^2+vy_nrho^2+vz_nrho^2);vz_nrho+x(2)*vz_nrho/sqrt(vx_nrho^2+vy_nrho^2+vz_nrho^2)];
       target_point = [-miu, 0, 0]; 
     options = odeset('RelTol' , 1e-12 , 'AbsTol' , 1e-12 ,'Events', @eventFunction);
 [t,xa] = ode113(@vdp1,  [tauf ,x(4)] ,  xx_rot,options);
 distances = sqrt(sum((xa(:, 1:3) - target_point).^2, 2)); % 计算每个点的距离  

hold on;plot3(1-miu,0,0,'k*');
   dvee=dve2(xx_rot, [tauf ,x(4)] );
     hold on; 
  [minDist, minIndex] = min(distances);
    % --------------------------- 保存转移轨道初值 ---------------------------

hold on;aux = get_NRHO();
  if abs(min(distances)-0.02)==0.003
             continue;
end
     hold on; 
plot3(xa(:,1),xa(:,2),xa(:,3));hold on;plot3(xa(1,1),xa(1,2),xa(1,3),'+');hold on;
plot3(-miu,0,0,'*');plot3(xa( minIndex,1),xa( minIndex,2),xa( minIndex,3),'+');hold on;view(45,45);
    resultMtx{iLoop} = [ xx_rot' ,  xa(minIndex,:) , sigma,thetas,tauf ,t(minIndex) ,op, dvee,abs(min(distances)-0.02)];

end



resultMtx(cellfun(@isempty , resultMtx)) = [];
candi_LEO2DRO2 = zeros(size(resultMtx , 1) , size(resultMtx{1} , 2));
for iLoop = 1 : size(resultMtx , 1)
    candi_LEO2DRO2(iLoop , :) = resultMtx{iLoop};
end

save candi_LEO2DRO2

fprintf('candi_DRO2LLO 计算完毕！ \n')
fprintf('轨道初值: %0.0f \n' , calNum)
fprintf('DRO反向积分至LEO轨道数: %0.0f \n' , size(candi_LEO2DRO2 , 1))


%%
function [x] =ffmincon(ug)
global lb ub
options = optimoptions(@fmincon,'Algorithm','sqp','MaxIterations',20,'Display','iter','MaxFunctionEvaluations',10000,'FunctionTolerance',1e-10,'ConstraintTolerance',1e-10);
x0=ug;
FCON = @(my)func2(my);
FOBJ=@(my)func3(my);
[x] = fmincon(@(my)FOBJ(my),x0,[],[],[],[],lb,ub,FCON,options);
end




function  [c,ceq] =func2(x)


t_star=4.3438*24*3600;
 global aux 
       sigma = x(1);
    % dro入轨点状态 (LU , VU)
    periOrb_x = interp1(aux.periOrb_tt , aux.periOrb_xx , sigma * aux.periOrb_P , 'spline')';
    x_nrho = periOrb_x(1,1);
    y_nrho = periOrb_x(2,1);
    z_nrho = periOrb_x(3,1);
    vx_nrho = periOrb_x(4,1);
    vy_nrho = periOrb_x(5,1);
    vz_nrho = periOrb_x(6,1);

    % 计算卫星入轨状态
    xx_rot = [x_nrho ;y_nrho ;z_nrho;vx_nrho+x(2)*vx_nrho/sqrt(vx_nrho^2+vy_nrho^2+vz_nrho^2);vy_nrho+x(2)*vy_nrho/sqrt(vx_nrho^2+vy_nrho^2+vz_nrho^2);vz_nrho+x(2)*vz_nrho/sqrt(vx_nrho^2+vy_nrho^2+vz_nrho^2)];
   
tauf =x(3) / -0.925195985520347;

miu=0.01215;


  target_point = [-miu, 0, 0]; 
     options = odeset('RelTol' , 1e-12 , 'AbsTol' , 1e-12 ,'Events', @eventFunction);
 [t,xa] = ode45(@vdp1,  [tauf ,x(4)] ,  xx_rot,options);
  ib=dve3(xx_rot, [tauf ,x(4)] );
 distances = sqrt(sum((xa(:, 1:3) - target_point).^2, 2)); % 计算每个点的距离  
    [minDist, minIndex] = min(distances);
vai=norm(xa(minIndex,4:6)/norm(xa(minIndex,4:6))-ib);


c=[];
ceq=vai;%;
end
function  f =func3(x)
t_star=4.3438*24*3600;
 global aux 
       sigma = x(1);
    % dro入轨点状态 (LU , VU)
    periOrb_x = interp1(aux.periOrb_tt , aux.periOrb_xx , sigma * aux.periOrb_P , 'spline')';
    x_nrho = periOrb_x(1,1);
    y_nrho = periOrb_x(2,1);
    z_nrho = periOrb_x(3,1);
    vx_nrho = periOrb_x(4,1);
    vy_nrho = periOrb_x(5,1);
    vz_nrho = periOrb_x(6,1);

    % 计算卫星入轨状态
    xx_rot = [x_nrho ;y_nrho ;z_nrho;vx_nrho+x(2)*vx_nrho/sqrt(vx_nrho^2+vy_nrho^2+vz_nrho^2);vy_nrho+x(2)*vy_nrho/sqrt(vx_nrho^2+vy_nrho^2+vz_nrho^2);vz_nrho+x(2)*vz_nrho/sqrt(vx_nrho^2+vy_nrho^2+vz_nrho^2)];
   
tauf =x(3) / -0.925195985520347;

miu=0.01215;


  target_point = [-miu, 0, 0]; 
     options = odeset('RelTol' , 1e-12 , 'AbsTol' , 1e-12 ,'Events', @eventFunction);
 [t,xa] = ode45(@vdp1,  [tauf ,x(4)] ,  xx_rot,options);
  dvee=dve(xx_rot, [tauf ,x(4)] );
 distances = sqrt(sum((xa(:, 1:3) - target_point).^2, 2)); % 计算每个点的距离  
      f = 10*abs(min(distances)-0.02); % 获取最小距离 
    % 返回最小距离  
  
end




function [value, isterminal, direction] = eventFunction(t, x)  
    miu = 0.01215;  
    distance_from_target1 = norm([x(1), x(2), x(3)] - [-miu, 0, 0]);  
    distance_from_target2 = norm([x(1), x(2), x(3)] - [1-miu, 0, 0]);  
    if distance_from_target1 - 0.017<0|| distance_from_target2-0.0057<0
    % 仅在距离小于0.5时触发  
    value = 0;
    else 
        value=1;
    end
    isterminal = 1; % 终止积分  
    direction = 0; % 在任何方向都检测  
    end
function dv=dve(x1,tt)
miu=0.01215;                

 options = odeset('RelTol' , 1e-12 , 'AbsTol' , 1e-12 ,'Events', @eventFunction);
[ta2, xa2] = ode45(@(t, y) vdp1(t, y), [tt(1), tt(2)], x1,options);%15386831.7932505

%plot3(-miu,0,0,'b+');hold on;hold on;plot3(xa2(1,1),xa2(1,2),xa2(1,3),'k*');hold on;plot3(xa2(:,1),xa2(:,2),xa2(:,3),'b');
%plot(xa2(:,1),xa2(:,2));hold on;
at= xa2(:,1:3)-[-miu,0,0];  
squared_sums = sqrt(sum(at.^2, 2)); % 计算每一行的平方和  

% 找到最小平方和的值及对应的行索引  
[min_value, min_index] = min(squared_sums);  
% 找到最小值的索引  


xf=xa2(min_index,1:6);
xaaf=xa2(min_index,1:6)';
hold on;
%plot3(xf(1,1),xf(1,2),xf(1,3),'g*')

%%
r=min_value;vv=sqrt((1-miu)/(r));%v=sqrt(mu2/(Rr));

%plot(xa(:,1),xa(:,2));hold on;
p1=1;t1=0;
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xf(pp1,1),xf(pp1,2),xf(pp1,4),xf(pp1,5)]';
xat1=[];
xat1=(R1)*(xroa1-da1);
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
b=[zz1(3,1),zz1(4,1),xf(1,6)];
a=[zz1(1,1),zz1(2,1),xf(1,3)];
vc=vv;
Aa=cross(a,b);
ia=Aa/norm(Aa);
Ba=cross(ia,a);
ib=Ba/norm(Ba);
vca=vc*ib;

dv=norm(b-vca);
end
function ib=dve3(x1,tt)
miu=0.01215;                

 options = odeset('RelTol' , 1e-12 , 'AbsTol' , 1e-12 ,'Events', @eventFunction);
[ta2, xa2] = ode45(@(t, y) vdp1(t, y), [tt(1), tt(2)], x1,options);%15386831.7932505

%plot3(-miu,0,0,'b+');hold on;hold on;plot3(xa2(1,1),xa2(1,2),xa2(1,3),'k*');hold on;plot3(xa2(:,1),xa2(:,2),xa2(:,3),'b');
%plot(xa2(:,1),xa2(:,2));hold on;
at= xa2(:,1:3)-[-miu,0,0];  
squared_sums = sqrt(sum(at.^2, 2)); % 计算每一行的平方和  

% 找到最小平方和的值及对应的行索引  
[min_value, min_index] = min(squared_sums);  
% 找到最小值的索引  


xf=xa2(min_index,1:6);
xaaf=xa2(min_index,1:6)';
hold on;
%plot3(xf(1,1),xf(1,2),xf(1,3),'g*')

%%
r=min_value;vv=sqrt((1-miu)/(r));%v=sqrt(mu2/(Rr));

%plot(xa(:,1),xa(:,2));hold on;
p1=1;t1=0;
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xf(pp1,1),xf(pp1,2),xf(pp1,4),xf(pp1,5)]';
xat1=[];
xat1=(R1)*(xroa1-da1);
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
b=[zz1(3,1),zz1(4,1),xf(1,6)];
a=[zz1(1,1),zz1(2,1),xf(1,3)];
vc=vv;
Aa=cross(a,b);
ia=Aa/norm(Aa);
Ba=cross(ia,a);
ib=Ba/norm(Ba);
vca=vc*ib;

dv=norm(b-vca);
end
function dv=dve2(x1,tt)
miu=0.01215;                

 options = odeset('RelTol' , 1e-12, 'AbsTol' , 1e-12 ,'Events', @eventFunction);


[ta2, xa2] = ode45(@(t, y) vdp1(t, y), [tt(1),tt(2)], x1,options);%15386831.7932505

plot3(-miu,0,0,'b+');hold on;hold on;plot3(xa2(1,1),xa2(1,2),xa2(1,3),'k*');hold on;
plot3(xa2(:,1),xa2(:,2),xa2(:,3),'r');
%plot(xa2(:,1),xa2(:,2));hold on;
at= xa2(:,1:3)-[-miu,0,0];  
squared_sums = sqrt(sum(at.^2, 2)); % 计算每一行的平方和  

% 找到最小平方和的值及对应的行索引  
[min_value, min_index] = min(squared_sums);  
% 找到最小值的索引  


xf=xa2(min_index,1:6);
xaaf=xa2(min_index,1:6)';
hold on;
plot3(xf(1,1),xf(1,2),xf(1,3),'g*')

%%
r=min_value;vv=sqrt((1-miu)/(r));%v=sqrt(mu2/(Rr));

%plot(xa(:,1),xa(:,2));hold on;
p1=1;t1=0;
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xf(pp1,1),xf(pp1,2),xf(pp1,4),xf(pp1,5)]';
xat1=[];
xat1=(R1)*(xroa1-da1);
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
b=[zz1(3,1),zz1(4,1),xf(1,6)];
a=[zz1(1,1),zz1(2,1),xf(1,3)];
vc=vv;
Aa=cross(a,b);
ia=Aa/norm(Aa);
Ba=cross(ia,a);
ib=Ba/norm(Ba);
vca=vc*ib;

dv=norm(b-vca);
p1=1;t1=0;%-theta;
xa3=[a,vca];

zz1=[];
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xa3(pp1,1),xa3(pp1,2),xa3(pp1,4),xa3(pp1,5)]';
xat1=[];
xat1=inv(R1)*(xroa1)+da1;
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
%plot(zz1(1,1),zz1(2,1),'y*');
zz2=[zz1(1,1),zz1(2,1),xa3(1,3),zz1(3,1),zz1(4,1),xa3(1,6)];
[ta4, xa4] = ode45(@(t, y) vdp1(t, y), [0,2*3.1415*r/vv], zz2);
plot3(xa4(:,1),xa4(:,2),xa4(:,3),'y');hold on;axis equal;  
axis equal;  

end
function result=vdp1(t,x)

u=0.01215;
R=389.1723985;%太阳转动半径（km）
ws = -0.925195985520347;%太阳转动频率
theta=ws*t;
m_s0=1.989e30;%太阳质量
m1=5.965e24;%地球质量
m2=7.342e22;%月球质量
m_s=m_s0/(m1+m2);
r=[x(1);x(2);x(3)];re=[-u;0;0];rm=[1-u;0;0];
r1=norm(r-re);r2=norm(r-rm);
r3=sqrt((x(1)-R*cos(theta))^2+(x(2)-R*sin(theta))^2+x(3)^2);
a_sx=-m_s*(x(1)-R*cos(theta))/(r3)^3-m_s*cos(theta)/R^2;
a_sy=-m_s*(x(2)-R*sin(theta))/(r3)^3-m_s*sin(theta)/R^2;
a_sz=-m_s*x(3)/(r3)^3;
xx=x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3+a_sx;
yy=x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3+a_sy;
zz=-(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3+a_sz;
result=[x(4);x(5);x(6);xx;yy;zz];
end