
function [value, isterminal, direction] = Bcr4bp_EventEMRot2DEarthAp(tau , xx , aux)
%
% 积分终止条件，EMRot，远地点（距地心 120e4 - 200e4 km）


% ---------------- 载入参数 ----------------
mu =0.01215;

l_star = 384400;

xc = xx(1);
yc = xx(2);
zc = xx(3);
vxc = xx(4);
vyc = xx(5);
vzc = xx(6);
%% --------------- 卫星加速度 ---------------
dxx =vdp1(tau , xx );
axc = dxx(3);
ayc = dxx(4);

% 远P1点/近P1点终止条件
stopCond1 = (xc + mu) * vxc + yc * vyc;

% 远P1点条件
cons1 = (vxc^2 + (xc + mu) * axc + vyc^2 + yc * ayc) < 0;

% 和P1距离条件（3 - 5倍地月距）
R_P1 = sqrt((xc + mu)^2 + yc^2+zc^2);
cons2 = R_P1 > (100e4) / l_star;
cons3 = R_P1 < (200e4) / l_star;

%% --------------- 满足所有约束条件 ---------------
if cons2 
    
     value = [];  
    
else
    
 value = 1;
    
end

% isterminal = 0; % 是否执行积分终止条件(多次)
isterminal = 1; % 是否执行积分终止条件(单次)

direction = 0; % 积分终止方向，由正向负或者由负向正

end
