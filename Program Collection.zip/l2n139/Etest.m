%%%初始控制变量生成程序,定dv，动nrho,单一轨道实验程序
close all;
clear;
 global aux bei0
global lb ub 
global closeApproaches t0
closeApproaches =0;
t0=0;
aux = get_NRHO();
t_star=4.3438*24*3600;
node=20;
datan=[];

dataMatrix= load('first.txt');
for hu=5:5%length(dataMatrix)

[x01,bei0]=supporte(dataMatrix(hu,:),1);

[x02,bei0]=supporte(dataMatrix(hu,:),2);


close all;
derz=-0.0001;
miu=0.01215;
datam=[];
for i=1:1
clc    
    %预测步
 x03 = x02 +(x02-x01)/((x02(node*6+4,1)-x01(node*6+4,1)))* derz;
yy=x03;
    count=0;    
    err = inf;
     if ~isreal(yy)
     break;
 end
    %校正步
    while  err > 1e-8 && count <10
 if ~isreal(yy)
     break;
 end
 
  if (abs(yy(121,1)-yy(122,1)))>40
     break;
 end
[c, ceq, Gc, Gceq]=ceqc(yy);
FK=ceq;
DFK=Gceq';
        err = max(abs(FK));
 yy=yy-DFK\FK;
count = count + 1;  %fprintf('迭代数: %0.0f, 误差: %0.2e \n' , count , err)
    end
     if ~isreal(yy)
     break;
 end
    %%
[c, ceq, Gc, Gceq]=ceqc(yy);
 x01=x02;
 x02=yy;
   options = odeset('RelTol' , 1e-12 , 'AbsTol' , 1e-12 ,'Events', @eventFunction);
   ay=turrn(yy(1:6));
    [seg_tt , seg_xx] = ode113(@vdp2 , [yy(node*6+1,1), yy(node*6+2,1)] , ay, options );
hold on;plot3(seg_xx(:,1),seg_xx(:,2),seg_xx(:,3));plot3(1-miu,0,0,'*');plot3(-miu,0,0,'*');view(45,45);aux = get_NRHO();
%%约束计算程序
zz(:,i)=yy;
disp(yy(node*6+4,1));
m0=turrn(yy(1:6,1));
dv=dve(m0,[yy(121,1),yy(122,1)]);
%disp(dv);
if  yy(node*6+4,1)<0
    break;
end
if dv<2.6||dv>3.2
    break;
end
datam(i,:)=[m0',yy(121,1),yy(122,1),yy(123,1),yy(124,1),dv];

end

if isempty(datam) 
datan=[datan;[]];
else 
    datan=[datan;datam(:,:)];
   
end

 disp(['近月次数: ', num2str(closeApproaches)]);
 if closeApproaches>1
     break;
 end
end

%%
function dv=dve(x1,tt)
miu=0.01215;                

 options = odeset('RelTol' , 1e-12 , 'AbsTol' , 1e-12 ,'Events', @eventFunction);
[ta2, xa2] = ode45(@(t, y) vdp2(t, y), [tt(1), tt(2)], x1,options);%15386831.7932505

%plot3(-miu,0,0,'b+');hold on;hold on;plot3(xa2(1,1),xa2(1,2),xa2(1,3),'k*');hold on;plot3(xa2(:,1),xa2(:,2),xa2(:,3),'b');
%plot(xa2(:,1),xa2(:,2));hold on;
at= xa2(:,1:3)-[-miu,0,0];  
squared_sums = sqrt(sum(at.^2, 2)); % 计算每一行的平方和  

% 找到最小平方和的值及对应的行索引  
[min_value, min_index] = min(squared_sums);  
% 找到最小值的索引  


xf=xa2(min_index,1:6);
xaaf=xa2(min_index,1:6)';
hold on;
%plot3(xf(1,1),xf(1,2),xf(1,3),'g*')

%%
r=min_value;vv=sqrt((1-miu)/(r));%v=sqrt(mu2/(Rr));

%plot(xa(:,1),xa(:,2));hold on;
p1=1;t1=0;
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xf(pp1,1),xf(pp1,2),xf(pp1,4),xf(pp1,5)]';
xat1=[];
xat1=(R1)*(xroa1-da1);
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
b=[zz1(3,1),zz1(4,1),xf(1,6)];
a=[zz1(1,1),zz1(2,1),xf(1,3)];
vc=vv;
Aa=cross(a,b);
ia=Aa/norm(Aa);
Ba=cross(ia,a);
ib=Ba/norm(Ba);
vca=vc*ib;

dv=norm(b-vca);
end
%%
function [c, ceq, Gc, Gceq] =ceqc(vars)

 global aux bei0
c = [];
ceq = [];
Gc = [];
Gceq = [];
nVar = size(vars , 1);

% 节点数
nNode =20;

% 状态矩阵
var_mtx = reshape(vars(1 : 6 * nNode) , 6 , nNode); % 状态

% 开始时间
tau_1 = vars(6 * nNode + 1);

% 结束时间
tau_f = vars(6 * nNode + 2);

% DRO相位角
sigma = vars(6 * nNode + 3);
op= vars(6 * nNode + 4);

  periOrb_x = interp1(aux.periOrb_tt , aux.periOrb_xx , sigma * aux.periOrb_P , 'spline')';
    x_nrho = periOrb_x(1);
    y_nrho = periOrb_x(2);
    z_nrho = periOrb_x(3);
    vx_nrho = periOrb_x(4);
    vy_nrho = periOrb_x(5);
    vz_nrho = periOrb_x(6);
    xnrho=[ x_nrho; y_nrho ;z_nrho ;vx_nrho;vy_nrho;vz_nrho];
    % 计算卫星入轨状态
    xx_rot = [x_nrho ;...
        y_nrho ;
         z_nrho ;
        vx_nrho+op*vx_nrho/sqrt(vx_nrho^2+vy_nrho^2+vz_nrho^2);
        vy_nrho+op*vy_nrho/sqrt(vx_nrho^2+vy_nrho^2+vz_nrho^2);
         vz_nrho+op*vz_nrho/sqrt(vx_nrho^2+vy_nrho^2+vz_nrho^2)];
     
     c = [];
Gc = [];

% 状态连接约束
stateCeq = zeros(6* (nNode - 1) , 1);
stateGceq = zeros(6 * (nNode - 1) , nVar);
stateCeqCount = 0;

% 保存每段时间和状态
seg_tt_all = [];
seg_xx_all = [];
tau_vec = linspace(tau_1 , tau_f , nNode)';
% 构造多步打靶约束
for jLoop = 1 : (nNode - 1)

    % 提取单轨道段两端的时刻
    tau_k = tau_vec(jLoop);
    tau_kp1 = tau_vec(jLoop + 1);

    % 提取单轨道段两端的打靶变量
    var_tauk = var_mtx(: , jLoop);
    var_taukp1 = var_mtx(: , jLoop + 1);

    % 提取单轨道段两端的状态变量
    if jLoop == 1

        xx_tauk = turrn(var_mtx(: , 1));
      
        xx_taukp1 = var_mtx(: , jLoop + 1);

        %     elseif jLoop == (nNode - 1)
        %
        %         xx_tauk = var_mtx(: , jLoop);
        %         xx_taukp1 = Bcr4bp_var2xxEMRot2D(var_mtx(: , nNode) , 'llo' , aux);
        %         xx_taukp1 = xx_taukp1';

    else

        xx_tauk = var_mtx(: , jLoop);
        xx_taukp1 = var_mtx(: , jLoop + 1);

    end

    % 数值积分
    phi0 = eye(6);
   options = odeset('RelTol' , 1e-12 , 'AbsTol' , 1e-12 );
    [seg_tt , seg_xx] = ode113(@vdp1 , [tau_k , tau_kp1] , [xx_tauk ; phi0(:)] , options );

    %     % 【测试】
    %     plotOrb2D(seg_xx , 'r' , 3);

    % 保存全部轨道


    % 积分终端状态
    xx_taukp1_ = seg_xx(end , 1 : 6)';

    % 状态转移矩阵
    phi_tauk_taukp1 = reshape(seg_xx(end , 7 : 42) , 6 , 6);

    % 状态连接约束和梯度
    [stateCeqN_temp , stateCeq_temp , stateGceq_temp] =yueshu(tau_k , xx_tauk , var_tauk , ...
        tau_kp1 , xx_taukp1 , var_taukp1 , ...
        xx_taukp1_ , phi_tauk_taukp1 , nVar , nNode , jLoop );

    % 【测试】
    %     stateCeq_temp

    % 更新
    stateCeq(stateCeqCount + 1 : stateCeqCount + stateCeqN_temp , :) = stateCeq_temp;
    stateGceq(stateCeqCount + 1 : stateCeqCount + stateCeqN_temp , :) = stateGceq_temp;
    stateCeqCount = stateCeqCount + stateCeqN_temp;

end

%% ---------------------------------------------- dep 约束 ------------------------------------------


rp = var_mtx(1 , 1);
cita = var_mtx(2 , 1);
ou = var_mtx(3 , 1);
i = var_mtx(4 , 1);
bei= var_mtx(5 , 1);
temp1= var_mtx(6 , 1);
% LEO约束
depCeq = [rp-0.02;
    bei-bei0;
    temp1];

% LEO约束梯度
depGceq = zeros(2 , nVar);
depGceq(1 , 1) = 1;

depGceq(2 , 5) = 1;
depGceq(3 , 6) = 1;
%% ---------------------------------------------- arr 约束 ------------------------------------------
xn = var_mtx(1 , end);
yn = var_mtx(2 , end);
zn = var_mtx(3 , end);
vxn = var_mtx(4 , end);
vyn = var_mtx(5 , end);
vzn = var_mtx(6 , end);
% DRO入轨约束
arrCeq = [xn-xx_rot(1,1);
    yn-xx_rot(2,1);
    zn-xx_rot(3,1);
    vxn-xx_rot(4,1);
    vyn-xx_rot(5,1);
      vzn-xx_rot(6,1)];

% 【测试】
% syms x_dro y_dro vx_dro vy_dro dvMag
% XX = [x_dro;
%     y_dro;
%     vx_dro + dvMag * vx_dro / sqrt(vx_dro^2 + vy_dro^2);
%     vy_dro + dvMag * vy_dro / sqrt(vx_dro^2 + vy_dro^2)];
% simplify(jacobian(XX , [x_dro ; y_dro ; vx_dro ; vy_dro]))
dvMag=op;
pDro_pt=vdp2(tau_f,xnrho);
part1 =[ 1, 0, 0,                                                                                                                         0,                                                                                                                         0,                                                                                                                         0;
 0, 1, 0,                                                                                                                         0,                                                                                                                         0,                                                                                                                         0;
0, 0, 1,                                                                                                                         0,                                                                                                                         0,                                                                                                                         0;
 0, 0, 0, ((vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2) + dvMag*vy_nrho^2 + dvMag*vz_nrho^2)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2),                                                        -(dvMag*vx_nrho*vy_nrho)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2),                                                        -(dvMag*vx_nrho*vz_nrho)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2);
 0, 0, 0,                                                        -(dvMag*vx_nrho*vy_nrho)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2), ((vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2) + dvMag*vx_nrho^2 + dvMag*vz_nrho^2)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2),                                                        -(dvMag*vy_nrho*vz_nrho)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2);
0, 0, 0,                                                        -(dvMag*vx_nrho*vz_nrho)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2),                                                        -(dvMag*vy_nrho*vz_nrho)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2), ((vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2) + dvMag*vx_nrho^2 + dvMag*vy_nrho^2)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2)];
 
part4=[0;0;0;vx_nrho/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(1/2);vy_nrho/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(1/2);vz_nrho/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(1/2)];
 
part2 = pDro_pt;
part3 = aux.periOrb_P;

arrGceq = zeros(6 , nVar);
arrGceq(: , 6 * (nNode - 1) + 1 : 6 * nNode) = eye(6);
arrGceq(: , 6* nNode + 3) = - part1 * part2 * part3;
arrGceq(: , 6* nNode + 4) = - part4;
%% 拼约束和梯度
% 约束拼接
ceq = [stateCeq ; depCeq ; arrCeq];

% 梯度拼接
Gceq = [stateGceq ; depGceq ; arrGceq];

% 构造约束和梯度
Gceq = Gceq';
Gc = Gc;
end
function [value, isterminal, direction] = eventFunction(t, x)  
global closeApproaches t0
    miu = 0.01215;  
    distance_from_target1 = norm([x(1), x(2), x(3)] - [-miu, 0, 0]);  
    distance_from_target2 = norm([x(1), x(2), x(3)] - [1-miu, 0, 0]);  
    if distance_from_target1 - 0.016<0|| distance_from_target2-0.0047<0
    % 仅在距离小于0.5时触发  
    value = 0;
    else 
        value=1;
    end

        if  distance_from_target2-0.1<0
if t0==0
t0=t;
   closeApproaches = closeApproaches + 1; % 增加计数器
else
    if abs(t-t0)>5
        t0=t;
           closeApproaches = closeApproaches + 1; % 增加计数器
    end
end
        end
    isterminal = 1; % 终止积分  
    direction = 0; % 在任何方向都检测  
    end
     
   function result=vdp1(t,x)

u=0.01215;
R=389.1723985;%太阳转动半径（km）
ws = -0.925195985520347;%太阳转动频率
theta=ws*t;
m_s0=1.989e30;%太阳质量
m1=5.965e24;%地球质量
m2=7.342e22;%月球质量
m_s=m_s0/(m1+m2);
r=[x(1);x(2);x(3)];re=[-u;0;0];rm=[1-u;0;0];
r1=norm(r-re);r2=norm(r-rm);
r3=sqrt((x(1)-R*cos(theta))^2+(x(2)-R*sin(theta))^2+x(3)^2);
a_sx=-m_s*(x(1)-R*cos(theta))/(r3)^3-m_s*cos(theta)/R^2;
a_sy=-m_s*(x(2)-R*sin(theta))/(r3)^3-m_s*sin(theta)/R^2;
a_sz=-m_s*x(3)/(r3)^3;

   r1_squared = r1^2;   
    r2_squared = r2^2;   
    r3_squared = r3^2;
 
    r1_cubed = r1_squared^(3/2);  
    r2_cubed = r2_squared^(3/2);  
    r3_cubed = r3_squared^(3/2);
 
    r1_fifth = r1_squared^(5/2);  
    r2_fifth = r2_squared^(5/2); 
    r3_fifth = r3_squared^(5/2);
    % 计算 U 系数  
    mu=u;
    Uxx=(mu - 1) / r1_cubed - mu / r2_cubed -m_s/r3_cubed +...
        (3*(u + x(1))^2*(1 - u))/(r1_fifth) +...
        (3*m_s*(x(1) - R*cos(theta))^2)/r3_fifth +...
        (3*u*(u + x(1) - 1)^2)/r2_fifth + 1;
 
    Uxy=(3*m_s*(x(1)-R*cos(theta))*(x(2)-R*sin(theta)))/r3_fifth+...
        (3*x(2)*(u + x(1))*(1-u))/r1_fifth +...
        (3*u*x(2)*(u + x(1) - 1))/r2_fifth;
 
    Uxz=(3*u*x(3)*(u + x(1) - 1))/r2_fifth +...
        (3*x(3)*(u + x(1))*(1 - u))/r1_fifth + ...
        (3*m_s*x(3)*(x(1) - R*cos(theta)))/r3_fifth; 
 
    Uyy=(u - 1)/r1_cubed-u/r2_cubed-m_s/r3_cubed +...
        (3*x(2)^2*(1 - u))/r1_fifth + (3*u*x(2)^2)/r2_fifth...
        + (3*m_s*(x(2)- R*sin(theta))^2)/r3_fifth + 1;
 
    Uyz=(3*m_s*x(3)*(x(2)-R*sin(theta)))/r3_fifth+...
        (3*x(2)*x(3)*(1 - u))/r1_fifth +...
        (3*u*x(2)*x(3))/r2_fifth;  
 
    Uzz= (u - 1)/r1_cubed- u/r2_cubed -m_s/r3_cubed+...
        (3*x(3)^2 * (1 - u)) / r1_fifth + ...  
        (3*u*x(3)^2) / r2_fifth+(3*m_s*x(3)^2)/r3_fifth;
     Xp = reshape(x(7:end), 6, 6);
         K = [0, 0, 0, 1, 0, 0;   
         0, 0, 0, 0, 1, 0;   
         0, 0, 0, 0, 0, 1;   
         Uxx, Uxy, Uxz, 0, 2, 0;   
         Uxy, Uyy, Uyz, -2, 0, 0;   
         Uxz, Uyz, Uzz, 0, 0, 0];  
    dXpdt = reshape(K * Xp, [], 1);
xx=x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3+a_sx;
yy=x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3+a_sy;
zz=-(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3+a_sz;
result=[x(4);x(5);x(6);xx;yy;zz;dXpdt];
   end

function [ceqNum , ceq , Gceq] = yueshu(tau_k , xx_tauk , var_tauk , ...
    tau_kp1 , xx_taukp1 , var_taukp1 , ...
    xx_taukp1_ , phi_tauk_taukp1 , nVar , nNode , jLoop )
%
% 构造状态连接约束
%
% 注意：
% 如果xxkp1是'dv'，则约束为r1f - r20
% 否则都为x1f - x20
%
% 作者：张晨
% 邮箱：chenzhang@csu.ac.cn
% 单位：中国科学院空间应用工程与技术中心，空间探索室
% 时间：2021年08月25日
%%%%%%%%%%%%%%%%%%%%%%%%

% ---------------------------------------------------------------------------
% tauk动力学
dxx_tauk =vdp2(tau_k , xx_tauk );

% taukp1_动力学
dxx_taukp1_ =vdp2(tau_kp1 , xx_taukp1_ );

% 模块
dtauj_dtau1 = 1 - (jLoop - 1) / (nNode - 1);
dtaujp1_dtau1 = 1 - jLoop / (nNode - 1);
dtauj_dtaun = (jLoop - 1) / (nNode - 1);
dtaujp1_dtaun = jLoop / (nNode - 1);

% ---------------------------------------------------------------------------
% 连接约束数
ceqNum =6;

% 约束
ceq = (xx_taukp1_ - xx_taukp1);

% 梯度预分配
Gceq = zeros(6 , nVar);

% --------------- 状态连接约束（梯度） -------------
% wrt xx_tauk
if jLoop == 1

    Gceq(:, 6 * (jLoop - 1) + 1 : 6 * jLoop) = phi_tauk_taukp1  * dxde_leo(var_tauk );

else

    Gceq(: ,6 * (jLoop - 1) + 1 : 6 * jLoop) = phi_tauk_taukp1;

end



    Gceq(: , 6* jLoop + 1 :6 * (jLoop + 1)) = - eye(6);



% 状态连接约束 wrt tau_1
Gceq(: , 6 * nNode + 1) = - phi_tauk_taukp1 * dxx_tauk * dtauj_dtau1 + dxx_taukp1_ * dtaujp1_dtau1;

% 状态连接约束 wrt tau_n
Gceq(: , 6 * nNode + 2) = - phi_tauk_taukp1 * dxx_tauk * dtauj_dtaun + dxx_taukp1_ * dtaujp1_dtaun;

end
function result=vdp2(t,x)

u=0.01215;
R=389.1723985;%太阳转动半径（km）
ws = -0.925195985520347;%太阳转动频率
theta=ws*t;
m_s0=1.989e30;%太阳质量
m1=5.965e24;%地球质量
m2=7.342e22;%月球质量
m_s=m_s0/(m1+m2);
r=[x(1);x(2);x(3)];re=[-u;0;0];rm=[1-u;0;0];
r1=norm(r-re);r2=norm(r-rm);
r3=sqrt((x(1)-R*cos(theta))^2+(x(2)-R*sin(theta))^2+x(3)^2);
a_sx=-m_s*(x(1)-R*cos(theta))/(r3)^3-m_s*cos(theta)/R^2;
a_sy=-m_s*(x(2)-R*sin(theta))/(r3)^3-m_s*sin(theta)/R^2;
a_sz=-m_s*x(3)/(r3)^3;
xx=x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3+a_sx;
yy=x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3+a_sy;
zz=-(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3+a_sz;
result=[x(4);x(5);x(6);xx;yy;zz];
end
function ba=dxde_leo(x)
rp=x(1);miu=0.01215;
i=x(4);
ou=x(3);
cita=x(2);
bei=x(5);
  ba=[cos(conj(cita))*cos(conj(ou)) - cos(conj(i))*sin(conj(cita))*sin(conj(ou)),-conj(rp)*(cos(conj(ou))*sin(conj(cita)) + cos(conj(cita))*cos(conj(i))*sin(conj(ou))),-conj(rp)*(cos(conj(cita))*sin(conj(ou)) + cos(conj(i))*cos(conj(ou))*sin(conj(cita))),sin(conj(cita))*sin(conj(i))*sin(conj(ou))*conj(rp),0,0;
        cos(conj(cita))*sin(conj(ou)) + cos(conj(i))*cos(conj(ou))*sin(conj(cita)),-conj(rp)*(sin(conj(cita))*sin(conj(ou)) - cos(conj(cita))*cos(conj(i))*cos(conj(ou))),conj(rp)*(cos(conj(cita))*cos(conj(ou)) - cos(conj(i))*sin(conj(cita))*sin(conj(ou))),-cos(conj(ou))*sin(conj(cita))*sin(conj(i))*conj(rp),0,0;
        sin(conj(cita))*sin(conj(i)),cos(conj(cita))*sin(conj(i))*conj(rp),0,cos(conj(i))*sin(conj(cita))*conj(rp),0,0;
       cos(conj(cita))*sin(conj(ou)) + cos(conj(i))*cos(conj(ou))*sin(conj(cita)) - (conj(bei)*(cos(conj(ou))*sin(conj(cita)) + cos(conj(cita))*cos(conj(i))*sin(conj(ou)))*(conj(miu) - 1))/(2*conj((-(miu - 1)/rp)^(1/2))*conj(rp)^2),- conj(rp)*(sin(conj(cita))*sin(conj(ou)) - cos(conj(cita))*cos(conj(i))*cos(conj(ou))) - conj((-(miu - 1)/rp)^(1/2))*conj(bei)*(cos(conj(cita))*cos(conj(ou)) - cos(conj(i))*sin(conj(cita))*sin(conj(ou))),conj(rp)*(cos(conj(cita))*cos(conj(ou)) - cos(conj(i))*sin(conj(cita))*sin(conj(ou))) + conj((-(miu - 1)/rp)^(1/2))*conj(bei)*(sin(conj(cita))*sin(conj(ou)) - cos(conj(cita))*cos(conj(i))*cos(conj(ou))),-sin(conj(i))*(cos(conj(ou))*sin(conj(cita))*conj(rp) - cos(conj(cita))*sin(conj(ou))*conj((-(miu - 1)/rp)^(1/2))*conj(bei)),-conj((-(miu - 1)/rp)^(1/2))*(cos(conj(ou))*sin(conj(cita)) + cos(conj(cita))*cos(conj(i))*sin(conj(ou))),0;
       cos(conj(i))*sin(conj(cita))*sin(conj(ou)) - cos(conj(cita))*cos(conj(ou)) - (conj(bei)*(sin(conj(cita))*sin(conj(ou)) - cos(conj(cita))*cos(conj(i))*cos(conj(ou)))*(conj(miu) - 1))/(2*conj((-(miu - 1)/rp)^(1/2))*conj(rp)^2),conj(rp)*(cos(conj(ou))*sin(conj(cita)) + cos(conj(cita))*cos(conj(i))*sin(conj(ou))) - conj((-(miu - 1)/rp)^(1/2))*conj(bei)*(cos(conj(cita))*sin(conj(ou)) + cos(conj(i))*cos(conj(ou))*sin(conj(cita))),conj(rp)*(cos(conj(cita))*sin(conj(ou)) + cos(conj(i))*cos(conj(ou))*sin(conj(cita))) - conj((-(miu - 1)/rp)^(1/2))*conj(bei)*(cos(conj(ou))*sin(conj(cita)) + cos(conj(cita))*cos(conj(i))*sin(conj(ou))),-sin(conj(i))*(sin(conj(cita))*sin(conj(ou))*conj(rp) + cos(conj(cita))*cos(conj(ou))*conj((-(miu - 1)/rp)^(1/2))*conj(bei)),-conj((-(miu - 1)/rp)^(1/2))*(sin(conj(cita))*sin(conj(ou)) - cos(conj(cita))*cos(conj(i))*cos(conj(ou))),0;
       (cos(conj(cita))*sin(conj(i))*conj(bei)*(conj(miu) - 1))/(2*conj((-(miu - 1)/rp)^(1/2))*conj(rp)^2),-sin(conj(cita))*sin(conj(i))*conj((-(miu - 1)/rp)^(1/2))*conj(bei),0,cos(conj(cita))*cos(conj(i))*conj((-(miu - 1)/rp)^(1/2))*conj(bei),cos(conj(cita))*sin(conj(i))*conj((-(miu - 1)/rp)^(1/2)),0;];
end

