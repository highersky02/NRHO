

%单点打靶法,三体模型案例


clear;close all;
global xx zz yy
X00 = eye(6);  
xaf=[-0.135617503469973,-0.157233873687402,-0.00556282453993065,1.93517229321101,-1.48956352772483,-0.948450163923447,-6.39219915028706,-31.0424681446992,1.00074990284285,0.0318468912714617,0.107191227261887,-0.0226325277241335,-0.0941330023820405,0.268428885526053];
in0=xaf(1,1:6)';xd=xaf(1,9:11);
options = odeset('RelTol' , 1e-10 , 'AbsTol' , 1e-10 ,'Events', @eventFunction);
DERS=0.001;	I= eye(6);  
x01=[0,0,0,xaf(1,7)]';te=x01(4,1);


%[t, xpp] = ode113(@ vdp1, [ te,xaf(1,8)], xd,options );hold on;plot3(xpp(:,1),xpp(:,2),xpp(:,3));

%[t3, xpp3] = ode113(@ vdp1,  [t(end) ,te], xpp(end,1:6),options );hold on;plot3(xpp3(:,1),xpp3(:,2),xpp3(:,3));


plot3(xd(1,1),xd(1,2),xd(1,3),'*');hold on;
plot3(in0(1,1),in0(2,1),in0(3,1),'k*');hold on;
view(45,45);

X0_vec = reshape(X00, [], 1); % 将单位矩阵展开为列向量  
% 创建新的列向量，将 x0 放在前面，后跟单位矩阵展开的列向量  
combined_vec = [in0; X0_vec]; 
% [t2, xpp2] = ode113(@ vdp1, [xaf(1,8) ,te], in0,options );hold on;plot3(xpp2(:,1),xpp2(:,2),xpp2(:,3));
 


% 结果 combined_vec 是一个 42x1 列向量（6+36=42）
    [t, Xp] = ode113(@ vdp1,  [xaf(1,8)  ,te],   combined_vec ,options ); 
% 结果 combined_vec 是一个 42x1 列向量（6+36=42）
   plot3( Xp(:,1), Xp(:,2), Xp(:,3));
   
   
   
     X_10s = reshape(Xp(end, 7:end), 6, 6);
      FK=[Xp(end,1)-xd(1,1),Xp(end,2)-xd(1,2),Xp(end,3)-xd(1,3)]';
DFK=[   X_10s(1,4),X_10s(1,5),X_10s(1,6),Xp(end,4);
    X_10s(2,4),X_10s(2,5),X_10s(2,6),Xp(end,5);
    X_10s(3,4),X_10s(3,5),X_10s(3,6),Xp(end,6)];
dk=-null(DFK);
ders=0.02;count=0;
for i=1:100
    %预测步
    x02 = x01 + dk * ders;
    count=0;    
    err = inf;
    %校正步
    while  err > 1e-8 && count <10

 x0=in0+[0;0;0;x02(1:3,1)];te=x02(4,1);
% 创建新的列向量，将 x0 放在前面，后跟单位矩阵展开的列向量  
combined_vec = [x0; X0_vec];   

% 结果 combined_vec 是一个 42x1 列向量（6+36=42）
    [t, Xp] = ode45(@ vdp1,  [xaf(1,8)  ,te],   combined_vec ,options );  
        
      X_10s = reshape(Xp(end, 7:end), 6, 6);
      FK=[Xp(end,1)-xd(1,1),Xp(end,2)-xd(1,2),Xp(end,3)-xd(1,3)]';
DFK=[   X_10s(1,4),X_10s(1,5),X_10s(1,6),Xp(end,4);
    X_10s(2,4),X_10s(2,5),X_10s(2,6),Xp(end,5);
    X_10s(3,4),X_10s(3,5),X_10s(3,6),Xp(end,6);];


        err = max(abs(FK));
 x02=x02-DFK\FK;
count = count + 1;
    end
    dk=-null(DFK);
    x01=x02;
    x0=in0+[0;0;0;x01(1:3,1)];te=x01(4,1);
  fprintf('迭代数: %0.0f, 误差: %0.2e \n' , i , err)
[t, xpp] = ode45(@ vdp2, [xaf(1,8)  ,te], x0,options );hold on;disp(te);
plot3(xpp(:,1),xpp(:,2),xpp(:,3));
end

function dydt=v4zt(t,x)
global xx yy zz;
u= -0.01215;

m_s0=1.989e30;%太阳质量
m1=5.965e24;%地球质量
m2=7.342e22;%月球质量
m_s=m_s0/(m1+m2);
R=389.1723985;%太阳转动半径（km）
ws = -0.925195985520347;%太阳转动频率
theta=ws*t;
%3.04036e-6;%0.0000779;%%%

r=[x(1);x(2);x(3)];re=[-u;0;0];rm=[1-u;0;0];
r1=norm(r-re);r2=norm(r-rm);
r3=sqrt((x(1)-R*cos(theta))^2+(x(2)-R*sin(theta))^2+x(3)^2);
a_sx=-m_s*(x(1)-R*cos(theta))/(r3)^3-m_s*cos(theta)/R^2;
a_sy=-m_s*(x(2)-R*sin(theta))/(r3)^3-m_s*sin(theta)/R^2;
a_sz=-m_s*x(3)/(r3)^3;

    r1_squared = r1^2;   
    r2_squared = r2^2;   
    r3_squared = r3^2;
 
    r1_cubed = r1_squared^(3/2);  
    r2_cubed = r2_squared^(3/2);  
    r3_cubed = r3_squared^(3/2);
 
    r1_fifth = r1_squared^(5/2);  
    r2_fifth = r2_squared^(5/2); 
    r3_fifth = r3_squared^(5/2);
    % 计算 U 系数  
    mu=u;
    Uxx=(mu - 1) / r1_cubed - mu / r2_cubed -m_s/r3_cubed +...
        (3*(u + x(1))^2*(1 - u))/(r1_fifth) +...
        (3*m_s*(x(1) - R*cos(theta))^2)/r3_fifth +...
        (3*u*(u + x(1) - 1)^2)/r2_fifth + 1;
 
    Uxy=(3*m_s*(x(1)-R*cos(theta))*(x(2)-R*sin(theta)))/r3_fifth+...
        (3*x(2)*(u + x(1))*(1-u))/r1_fifth +...
        (3*u*x(2)*(u + x(1) - 1))/r2_fifth;
 
    Uxz=(3*u*x(3)*(u + x(1) - 1))/r2_fifth +...
        (3*x(3)*(u + x(1))*(1 - u))/r1_fifth + ...
        (3*m_s*x(3)*(x(1) - R*cos(theta)))/r3_fifth; 
 
    Uyy=(u - 1)/r1_cubed-u/r2_cubed-m_s/r3_cubed +...
        (3*x(2)^2*(1 - u))/r1_fifth + (3*u*x(2)^2)/r2_fifth...
        + (3*m_s*(x(2)- R*sin(theta))^2)/r3_fifth + 1;
 
    Uyz=(3*m_s*x(3)*(x(2)-R*sin(theta)))/r3_fifth+...
        (3*x(2)*x(3)*(1 - u))/r1_fifth +...
        (3*u*x(2)*x(3))/r2_fifth;  
 
    Uzz= (u - 1)/r1_cubed- u/r2_cubed -m_s/r3_cubed+...
        (3*x(3)^2 * (1 - u)) / r1_fifth + ...  
        (3*u*x(3)^2) / r2_fifth+(3*m_s*x(3)^2)/r3_fifth;
 
    K = [0, 0, 0, 1, 0, 0;   
         0, 0, 0, 0, 1, 0;   
         0, 0, 0, 0, 0, 1;   
         Uxx, Uxy, Uxz, 0, 2, 0;   
         Uxy, Uyy, Uyz, -2, 0, 0;   
         Uxz, Uyz, Uzz, 0, 0, 0];  
    Xp = reshape(x(7:end), 6, 6);
    dXpdt = reshape(K * Xp, [], 1);
dydt=[x(4);...
     x(5);...
     x(6);...
     x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3+a_sx;...
     x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3+a_sy;...
     -(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3+a_sz;...
      dXpdt ];
  xx=x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3+a_sx;
yy=x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3+a_sy;
zz=-(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3+a_sz;
 
end

function [value, isterminal, direction] = eventFunction(t, x)  
    miu = 0.01215;  
    distance_from_target1 = norm([x(1), x(2), x(3)] - [-miu, 0, 0]);  
    distance_from_target2 = norm([x(1), x(2), x(3)] - [1-miu, 0, 0]);  
    if distance_from_target1 - 0.018<0|| distance_from_target2-0.0057<0
    % 仅在距离小于0.5时触发  
    value = 0;
    else 
        value=1;
    end
    isterminal = 1; % 终止积分  
    direction = 0; % 在任何方向都检测  
    end

function result=vdp1(t,x)

u=0.01215;
R=389.1723985;%太阳转动半径（km）
ws = -0.925195985520347;%太阳转动频率
theta=ws*t;
m_s0=1.989e30;%太阳质量
m1=5.965e24;%地球质量
m2=7.342e22;%月球质量
m_s=m_s0/(m1+m2);
r=[x(1);x(2);x(3)];re=[-u;0;0];rm=[1-u;0;0];
r1=norm(r-re);r2=norm(r-rm);
r3=sqrt((x(1)-R*cos(theta))^2+(x(2)-R*sin(theta))^2+x(3)^2);
a_sx=-m_s*(x(1)-R*cos(theta))/(r3)^3-m_s*cos(theta)/R^2;
a_sy=-m_s*(x(2)-R*sin(theta))/(r3)^3-m_s*sin(theta)/R^2;
a_sz=-m_s*x(3)/(r3)^3;





   r1_squared = r1^2;   
    r2_squared = r2^2;   
    r3_squared = r3^2;
 
    r1_cubed = r1_squared^(3/2);  
    r2_cubed = r2_squared^(3/2);  
    r3_cubed = r3_squared^(3/2);
 
    r1_fifth = r1_squared^(5/2);  
    r2_fifth = r2_squared^(5/2); 
    r3_fifth = r3_squared^(5/2);
    % 计算 U 系数  
    mu=u;
    Uxx=(mu - 1) / r1_cubed - mu / r2_cubed -m_s/r3_cubed +...
        (3*(u + x(1))^2*(1 - u))/(r1_fifth) +...
        (3*m_s*(x(1) - R*cos(theta))^2)/r3_fifth +...
        (3*u*(u + x(1) - 1)^2)/r2_fifth + 1;
 
    Uxy=(3*m_s*(x(1)-R*cos(theta))*(x(2)-R*sin(theta)))/r3_fifth+...
        (3*x(2)*(u + x(1))*(1-u))/r1_fifth +...
        (3*u*x(2)*(u + x(1) - 1))/r2_fifth;
 
    Uxz=(3*u*x(3)*(u + x(1) - 1))/r2_fifth +...
        (3*x(3)*(u + x(1))*(1 - u))/r1_fifth + ...
        (3*m_s*x(3)*(x(1) - R*cos(theta)))/r3_fifth; 
 
    Uyy=(u - 1)/r1_cubed-u/r2_cubed-m_s/r3_cubed +...
        (3*x(2)^2*(1 - u))/r1_fifth + (3*u*x(2)^2)/r2_fifth...
        + (3*m_s*(x(2)- R*sin(theta))^2)/r3_fifth + 1;
 
    Uyz=(3*m_s*x(3)*(x(2)-R*sin(theta)))/r3_fifth+...
        (3*x(2)*x(3)*(1 - u))/r1_fifth +...
        (3*u*x(2)*x(3))/r2_fifth;  
 
    Uzz= (u - 1)/r1_cubed- u/r2_cubed -m_s/r3_cubed+...
        (3*x(3)^2 * (1 - u)) / r1_fifth + ...  
        (3*u*x(3)^2) / r2_fifth+(3*m_s*x(3)^2)/r3_fifth;
     Xp = reshape(x(7:end), 6, 6);
         K = [0, 0, 0, 1, 0, 0;   
         0, 0, 0, 0, 1, 0;   
         0, 0, 0, 0, 0, 1;   
         Uxx, Uxy, Uxz, 0, 2, 0;   
         Uxy, Uyy, Uyz, -2, 0, 0;   
         Uxz, Uyz, Uzz, 0, 0, 0];  
    dXpdt = reshape(K * Xp, [], 1);
xx=x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3+a_sx;
yy=x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3+a_sy;
zz=-(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3+a_sz;
result=[x(4);x(5);x(6);xx;yy;zz;dXpdt];
end


function result=vdp2(t,x)

u=0.01215;
R=389.1723985;%太阳转动半径（km）
ws = -0.925195985520347;%太阳转动频率
theta=ws*t;
m_s0=1.989e30;%太阳质量
m1=5.965e24;%地球质量
m2=7.342e22;%月球质量
m_s=m_s0/(m1+m2);
r=[x(1);x(2);x(3)];re=[-u;0;0];rm=[1-u;0;0];
r1=norm(r-re);r2=norm(r-rm);
r3=sqrt((x(1)-R*cos(theta))^2+(x(2)-R*sin(theta))^2+x(3)^2);
a_sx=-m_s*(x(1)-R*cos(theta))/(r3)^3-m_s*cos(theta)/R^2;
a_sy=-m_s*(x(2)-R*sin(theta))/(r3)^3-m_s*sin(theta)/R^2;
a_sz=-m_s*x(3)/(r3)^3;
xx=x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3+a_sx;
yy=x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3+a_sy;
zz=-(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3+a_sz;
result=[x(4);x(5);x(6);xx;yy;zz];
end