datan2=load('seccond.txt');

data=datan2(20,:);
xv=data(1,7:12);
xc=turnn(xv);
xb=turrn(xc);