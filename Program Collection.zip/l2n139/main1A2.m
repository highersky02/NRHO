%%%%引力辅助优化程序
clear;
close all;
clc;
global aux  lb ub
aux = get_NRHO();
t_star=4.3438*24*3600;
% 参数设置  
options = optimoptions('gamultiobj', ...  
        'PopulationSize',10, ...        % 种群大小  
        'MaxGenerations', 10, ...        % 最大世代数  
        'Display', 'iter' );            % 显示每代信息  

ub = [0,0.6, 0.1, 0.1,0.1,80];      % 上界  
lb = [0,0.5, -0.1,-0.1,-0.1,80];  % 下界  
%xx = lb + (ub - lb) .* rand(1, length(lb));  
[x, fval] = gamultiobj(@VsumObjective, 6, [], [], [], [], lb, ub, @myNonlinearConstraints, options);
disp('开始序列二次规划');
%xx=[0,0.565039619954173,0.044592661611620,0.077529271545107,0.026964786298778,67.709512377287400]; %%9.924865e-02
%x=ffmincon(xx);
   miu=0.01215;
    t_star=4.3438*24*3600;
    tauf =x(1) / -0.925195985520347;
        sigma = x(2);
    % dro入轨点状态 (LU , VU)
    periOrb_x = interp1(aux.periOrb_tt , aux.periOrb_xx , sigma * aux.periOrb_P , 'spline')';
    x_nrho = periOrb_x(1,1);
    y_nrho = periOrb_x(2,1);
    z_nrho = periOrb_x(3,1);
    vx_nrho = periOrb_x(4,1);
    vy_nrho = periOrb_x(5,1);
    vz_nrho = periOrb_x(6,1);
target_point = [-miu, 0, 0]; 
    % 计算卫星入轨状态
    xx_rot = [x_nrho ;y_nrho ;z_nrho;vx_nrho+x(3);vy_nrho+x(4);vz_nrho+x(5)];
    options = odeset('RelTol' , 1e-8 , 'AbsTol' , 1e-8 );
   try
         options = odeset('RelTol' , 1e-10 , 'AbsTol' , 1e-10 , 'Events' , @EarthAp);
        [seg1_tt , xa, seg1_te , seg1_xe , seg1_ie] = ode45(@vdp1, ...
            [tauf , tauf -x(6) * 86400 / t_star] ,  xx_rot , options);
    
   end
  
    dvee=dve(xx_rot, [tauf , seg1_te ] );
 distances = sqrt(sum((xa(:, 1:3) - target_point).^2, 2)); % 计算每个点的距离  
   
    % 返回最小距离  
   f =norm(seg1_xe(1,1:3)-[-miu,0,0])+norm([x(3),x(4),x(5)])+dvee; % 获取最小距离 

   dvee=dve2(xx_rot, [tauf , tauf - x(6) * 86400 / t_star] );
  
plot3(xa(:,1),xa(:,2),xa(:,3));hold on;plot3(xa(1,1),xa(1,2),xa(1,3),'+');hold on;
plot3(-miu,0,0,'*');plot3(xa(end,1),xa( end,2),xa( end,3),'+');hold on;
%%
plot3(1-miu,0,0,'*');axis equal;
%%
%%

function [c, ceq] = myNonlinearConstraints(x)  
    c = []; % 没有不等式约束  
    ceq = []; % 没有等式约束  
end  

function f = VsumObjective(x)
global aux 
    % 目标函数  
    miu=0.01215;
    t_star=4.3438*24*3600;
    tauf =x(1) / -0.925195985520347;
        sigma = x(2);
    % dro入轨点状态 (LU , VU)
    periOrb_x = interp1(aux.periOrb_tt , aux.periOrb_xx , sigma * aux.periOrb_P , 'spline')';
    x_nrho = periOrb_x(1,1);
    y_nrho = periOrb_x(2,1);
    z_nrho = periOrb_x(3,1);
    vx_nrho = periOrb_x(4,1);
    vy_nrho = periOrb_x(5,1);
    vz_nrho = periOrb_x(6,1);

    % 计算卫星入轨状态
    xx_rot = [x_nrho ;y_nrho ;z_nrho;vx_nrho+x(3);vy_nrho+x(4);vz_nrho+x(5)];
      target_point = [-miu, 0, 0]; 
     options = odeset('RelTol' , 1e-8 , 'AbsTol' , 1e-8 );
   try
         options = odeset('RelTol' , 1e-10 , 'AbsTol' , 1e-10 , 'Events' , @EarthAp);
        [seg1_tt , xa , seg1_te , seg1_xe , seg1_ie] = ode45(@vdp1, ...
            [tauf , tauf -x(6) * 86400 / t_star] ,  xx_rot , options);

    end
 
 disp(seg1_ie);
 
 %distances = sqrt(sum((xa(:, 1:3) - target_point).^2, 2)); % 计算每个点的距离  


  
    dvee=dve(xx_rot, [tauf , seg1_te ] );

    % 返回最小距离  
   f =norm(seg1_xe(1,1:3)-[-miu,0,0])+norm([x(3),x(4),x(5)])+dvee; % 获取最小距离 

end
function [x] =ffmincon(ug)
global lb ub
options = optimoptions(@fmincon,'Algorithm','Interior-Point','MaxIterations',200,'Display','iter','MaxFunctionEvaluations',10000,'FunctionTolerance',1e-10,'ConstraintTolerance',1e-10);
x0=ug;
FCON = @(my)func2(my);
FOBJ=@(my) func3(my);
[x] = fmincon(@(my)FOBJ(my),x0,[],[],[],[],lb,ub,FCON,options);
end
function  [c,ceq] =func2(x)
c=[];
ceq=[];%;
end
%%
function f=func3(x)
global aux 
    % 目标函数  
    miu=0.01215;
    t_star=4.3438*24*3600;
    tauf =x(1) / -0.925195985520347;
        sigma = x(2);
    % dro入轨点状态 (LU , VU)
    periOrb_x = interp1(aux.periOrb_tt , aux.periOrb_xx , sigma * aux.periOrb_P , 'spline')';
    x_nrho = periOrb_x(1,1);
    y_nrho = periOrb_x(2,1);
    z_nrho = periOrb_x(3,1);
    vx_nrho = periOrb_x(4,1);
    vy_nrho = periOrb_x(5,1);
    vz_nrho = periOrb_x(6,1);

    % 计算卫星入轨状态
    xx_rot = [x_nrho ;y_nrho ;z_nrho;vx_nrho+x(3);vy_nrho+x(4);vz_nrho+x(5)];
       target_point = [-miu, 0, 0]; 
     options = odeset('RelTol' , 1e-8 , 'AbsTol' , 1e-8);
 [t,xa] = ode45(@vdp1,  [tauf , tauf - x(6) * 86400 / t_star] ,  xx_rot,options);
 
   try
         options = odeset('RelTol' , 1e-10 , 'AbsTol' , 1e-10 , 'Events' , @EarthAp);
        [seg1_tt , seg1_xx , seg1_te , seg1_xe , seg1_ie] = ode45(@vdp1, ...
            [tauf , tauf -x(6) * 86400 / t_star] ,  xx_rot , options);
    
    end
 
 
 
 %distances = sqrt(sum((xa(:, 1:3) - target_point).^2, 2)); % 计算每个点的距离  
   
    % 返回最小距离  
   f =norm(seg1_xe(1,1:3)-[-miu,0,0]); % 获取最小距离 

end



function dydt=myfunction(t,y)

end



function [t,y]=result(x)

end




function dv=dve(x1,tt)
miu=0.01215;                
options = odeset('RelTol',1e-12,'AbsTol',1e-12);


[ta2, xa2] = ode45(@(t, y) vdp1(t, y), [tt(1):-0.01:tt(2)], x1,options);%15386831.7932505
%plot(-miu,0,'b+');hold on;plot(1-miu,0,'bo');hold on;plot(x0(1,1),x0(1,2),'*');hold on;
%plot(xa2(:,1),xa2(:,2));hold on;
a= xa2(:,1:3)-[-miu,0,0];  
squared_sums = sqrt(sum(a.^2, 2)); % 计算每一行的平方和  

% 找到最小平方和的值及对应的行索引  
[min_value, min_index] = min(squared_sums);  
% 找到最小值的索引  

xf=xa2(min_index,1:6);
xaaf=xa2(min_index,1:6)';



hold on;
%plot(xf(1,1),xf(1,2),'g*')

%%
r=min_value;vv=sqrt((1-miu)/(r));%v=sqrt(mu2/(Rr));


%plot(xa(:,1),xa(:,2));hold on;
p1=length(xa2);t1=ta2;
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xa2(pp1,1),xa2(pp1,2),xa2(pp1,4),xa2(pp1,5)]';
xat1=[];
xat1=(R1)*(xroa1-da1);
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
dt=sqrt(zz1(3,min_index)^2+zz1(4,min_index)^2);
dv=abs(dt-vv);
end
function dv=dve2(x1,tt)
miu=0.01215;                
options = odeset('RelTol',1e-12,'AbsTol',1e-12);


[ta2, xa2] = ode45(@(t, y) vdp1(t, y), [tt(1):-0.01:tt(2)], x1,options);%15386831.7932505
%plot(-miu,0,'b+');hold on;plot(1-miu,0,'bo');hold on;plot(x0(1,1),x0(1,2),'*');hold on;
%plot(xa2(:,1),xa2(:,2));hold on;
a= xa2(:,1:3)-[-miu,0,0];  
squared_sums = sqrt(sum(a.^2, 2)); % 计算每一行的平方和  

% 找到最小平方和的值及对应的行索引  
[min_value, min_index] = min(squared_sums);  
% 找到最小值的索引  

xf=xa2(min_index,1:6);
xaaf=xa2(min_index,1:6)';



hold on;
plot(xf(1,1),xf(1,2),'g*')

%%
r=min_value;vv=sqrt((1-miu)/(r));%v=sqrt(mu2/(Rr));


%plot(xa(:,1),xa(:,2));hold on;
p1=length(xa2);t1=ta2;
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xa2(pp1,1),xa2(pp1,2),xa2(pp1,4),xa2(pp1,5)]';
xat1=[];
xat1=(R1)*(xroa1-da1);
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
dt=sqrt(zz1(3,min_index)^2+zz1(4,min_index)^2);
dv=abs(dt-vv);
p1=1;t1=0;%-theta;
xa3=[sqrt((zz1(1,min_index))^2+zz1(2,min_index)^2),0,0,-vv];

dis=sqrt(zz1(1,min_index)^2+zz1(2,min_index)^2);zz1=[];
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xa3(pp1,1),xa3(pp1,2),xa3(pp1,3),xa3(pp1,4)]';
xat1=[];
xat1=inv(R1)*(xroa1)+da1;
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
%plot(zz1(1,1),zz1(2,1),'y*');
zz2=[zz1(1,1),zz1(2,1),0,zz1(3,1),zz1(4,1),0];
[ta4, xa4] = ode45(@(t, y) vdp1(t, y), [0,2*3.1415*dis/vv], zz2,options);
plot(xa4(:,1),xa4(:,2));hold on;axis equal;  end