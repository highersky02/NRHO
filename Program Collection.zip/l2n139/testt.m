


clear;clc;close all;
miu=0.01215;
x=[1,3.1415/2,3.14/3,-3.14/2,0,0,0,0,0];
rp=x(1);i=x(2);ou=x(3);cita=x(4);bei=x(5);T1=x(6);T2=x(7);
sigma = x(8);

 rpa=[rp*(cos(cita)*cos(ou)-sin(cita)*sin(ou)*cos(i))+1-miu,rp*(cos(cita)*sin(ou)+sin(cita)*cos(ou)*cos(i)),rp*(sin(cita)*sin(i))];
         xx_rot =[rpa];
plot3(xx_rot(1,1),xx_rot(1,2),xx_rot(1,3),'*');hold on;
plot3(1-miu,0,0,'r*');plot3(-miu,0,0,'k*');grid on;                      % 开启网格  
xlabel('x');ylabel('y');