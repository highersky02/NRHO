%%%


for i=1:length(datan2)
sdv(i,1)=abs(datan2(i,17))+datan2(i,18);
end
[a,b]=min(sdv)

for i=1:length(datan3)
sdv(i,1)=abs(datan3(i,10))+datan3(i,11);
end
[a,b]=min(sdv)