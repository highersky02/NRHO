function result =turnn2(xaf )

    global xaf
miu=0.01215;






% 定义方程  
x0=turnn(xaf);
x=ffmincon(x0);
result=[x];
end
function [x] =ffmincon(ug)
global lb ub xf
options = optimoptions(@fmincon,'Algorithm','sqp ','MaxIterations',20,'MaxFunctionEvaluations',10000,'FunctionTolerance',1e-12,'ConstraintTolerance',1e-12);
x0=ug;
FCON = @(my)func2(my);
FOBJ=@(my)func3(my);
[x] = fmincon(@(my)FOBJ(my),x0,[],[],[],[],[],[],FCON,options);
end
function  [c,ceq] =func2(x)


c=[];
ceq=[];%;
end
function  f =func3(x)
    global xaf
    rp=x(1);
    cita=x(2);
    ou=x(3);
    ig=x(4);
    bei=x(5);
    miu=0.01215;
    eq1 = rp*(cos(cita)*cos(ou)-sin(cita)*sin(ou)*cos(ig))-miu-xaf(1,1);  
eq2 = rp*(cos(cita)*sin(ou)+sin(cita)*cos(ou)*cos(ig))-xaf(1,2);  
eq3 = rp*(sin(cita)*sin(ig))-xaf(1,3);  
eq4 =-bei*sqrt((1-miu)/rp)*(sin(cita)*cos(ou)+cos(cita)*sin(ou)*cos(ig))+rp*(cos(cita)*sin(ou)+sin(cita)*cos(ou)*cos(ig))-xaf(1,4);  
eq5 =-bei*sqrt((1-miu)/rp)*(sin(cita)*sin(ou)-cos(cita)*cos(ou)*cos(ig))+rp*(-cos(cita)*cos(ou)+sin(cita)*sin(ou)*cos(ig))-xaf(1,5);  
    eq6 = -bei*sqrt((1-miu)/rp)*(-cos(cita)*sin(ig))-xaf(1,6);


f = abs(eq1)+  abs(eq2)+  abs(eq3)+  abs(eq4)+  abs(eq5)+ abs(eq6);
    % 返回最小距离  
  
end

