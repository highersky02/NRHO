function dv=dve(x1,tt)
miu=0.01215;                
options = odeset('RelTol',1e-12,'AbsTol',1e-12);


[ta2, xa2] = ode45(@(t, y) vdp0(t, y), [tt(1):-0.01:tt(2)], x1,options);%15386831.7932505
%plot(-miu,0,'b+');hold on;plot(1-miu,0,'bo');hold on;plot(x0(1,1),x0(1,2),'*');hold on;
%plot(xa2(:,1),xa2(:,2));hold on;
a= xa2(:,1:3)-[-miu,0,0];  
squared_sums = sqrt(sum(a.^2, 2)); % 计算每一行的平方和  

% 找到最小平方和的值及对应的行索引  
[min_value, min_index] = min(squared_sums);  
% 找到最小值的索引  

xf=xa2(min_index,1:6);
xaaf=xa2(min_index,1:6)';



hold on;
plot(xf(1,1),xf(1,2),'g*')

%%
r=min_value;vv=sqrt((1-miu)/(r));%v=sqrt(mu2/(Rr));


%plot(xa(:,1),xa(:,2));hold on;
p1=length(xa2);t1=ta2;
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xa2(pp1,1),xa2(pp1,2),xa2(pp1,4),xa2(pp1,5)]';
xat1=[];
xat1=(R1)*(xroa1-da1);
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
dt=sqrt(zz1(3,min_index)^2+zz1(4,min_index)^2);
dv=abs(dt-vv);
end
function Loc=vdp0(t,x)


u=0.01215;
r=[x(1);x(2);x(3)];re=[-u;0;0];rm=[1-u;0;0];
r1=norm(r-re);r2=norm(r-rm);
Loc=[x(4);...
     x(5);...
     x(6);...
     x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3;...
     x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3;...
     -(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3];

end

