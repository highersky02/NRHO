 
clear;clc;close all;tauf=-0.1;t_star=4.3438*24*3600;
 options = odeset('RelTol' , 1e-10 , 'AbsTol' , 1e-10 ,'Events', @eventFunction);
xx_rot= [0.991885764198059;-0.028057481045978;0.043991166854174;-0.065707519008387;0.125395761396638;-0.592982491854310];
 [t,xa] = ode45(@vdp1,  [1 , -10] ,  xx_rot,options );
 hold on;
miu=0.01215;
aux = get_NRHO();target_point=[-miu,0,0];

   dvee=dve2(xx_rot, [1 , -90] );
 distances = sqrt(sum((xa(:, 1:3) - target_point).^2, 2)); % 计算每个点的距离  
     
  [minDist, minIndex] = min(distances);
  
plot3(xa(:,1),xa(:,2),xa(:,3));hold on;plot3(xa(1,1),xa(1,2),xa(1,3),'+');hold on;
plot3(-miu,0,0,'k*');plot3(xa( minIndex,1),xa( minIndex,2),xa( minIndex,3),'+');hold on;
%%


function dv=dve2(x1,tt)
miu=0.01215;                
  options = odeset('RelTol' , 1e-12 , 'AbsTol' , 1e-12 ,'Events', @eventFunction);

[ta2, xa2] = ode45(@(t, y) vdp1(t, y), [tt(1),tt(2)], x1);%15386831.7932505
%plot3(-miu,0,0,'b+');hold on;hold on;plot3(xa2(1,1),xa2(1,2),xa2(1,3),'k*');hold on;
%plot3(xa2(:,1),xa2(:,2),xa2(:,3),'b');
%plot(xa2(:,1),xa2(:,2));hold on;
  
% 找到最小值的索引  
 distances = sqrt(sum((xa2(:, 1:3) - [-miu,0,0]).^2, 2)); % 计算每个点的距离  
     
[min_value, min_index] = min(distances);
  

xf=xa2(min_index,1:6);
xaaf=xa2(min_index,1:6)';
hold on;
plot3(xf(1,1),xf(1,2),xf(1,3),'b*');hold on;

%%
r=min_value;vv=sqrt((1-miu)/(r));%v=sqrt(mu2/(Rr));

%plot(xa(:,1),xa(:,2));hold on;
p1=1;t1=0;
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xf(pp1,1),xf(pp1,2),xf(pp1,4),xf(pp1,5)]';
xat1=[];
xat1=(R1)*(xroa1-da1);
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
b=[zz1(3,1),zz1(4,1),xf(1,6)];
a=[zz1(1,1),zz1(2,1),xf(1,3)];
vc=vv;
Aa=cross(a,b);
ia=Aa/norm(Aa);
Ba=cross(ia,a);
ib=Ba/norm(Ba);
vca=vc*ib;

dv=norm(b-vca);
p1=1;t1=0;%-theta;
xa3=[a,vca];

zz1=[];
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xa3(pp1,1),xa3(pp1,2),xa3(pp1,4),xa3(pp1,5)]';
xat1=[];
xat1=inv(R1)*(xroa1)+da1;
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
%plot(zz1(1,1),zz1(2,1),'y*');
zz2=[zz1(1,1),zz1(2,1),xa3(1,3),zz1(3,1),zz1(4,1),xa3(1,6)];
[ta4, xa4] = ode45(@(t, y) vdp1(t, y), [0,2*3.1416*r/vv], zz2);disp('1');
plot3(xa4(:,1),xa4(:,2),xa4(:,3));hold on;axis equal;  
%plot3(xa4(1,1),xa4(1,2),xa4(1,3),'kO');hold on;axis equal; 
 function [value, isterminal, direction] = eventFunction(t, x)  
 miu = 0.01215;  
    distance_from_target1 = norm([x(1), x(2), x(3)] - [-miu, 0, 0]);  
    distance_from_target2 = norm([x(1), x(2), x(3)] - [1-miu, 0, 0]);  
    if distance_from_target1 - 0.1<0||distance_from_target2-0.0057<0
    % 仅在距离小于0.5时触发  
    value = 0;
    else 
        value=1;
    end
    isterminal = 1; % 终止积分  
    direction = 0; % 在任何方向都检测  
    end
end




 function [value, isterminal, direction] = eventFunction(t, x)  
 miu = 0.01215;  
    distance_from_target1 = norm([x(1), x(2), x(3)] - [-miu, 0, 0]);  
    distance_from_target2 = norm([x(1), x(2), x(3)] - [1-miu, 0, 0]);  
    if distance_from_target1 - 0.1<0||distance_from_target2-0.0057<0
    % 仅在距离小于0.5时触发  
    value = 0;
    else 
        value=1;
    end
    isterminal = 1; % 终止积分  
    direction = 0; % 在任何方向都检测  
    
    
    
    end
