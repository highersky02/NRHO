
function [value, isterminal, direction] = Bcr4bp_EventEMRot2DNRHORp(tau , x ,aux)
%
global aux
% 积分终止条件，EMRot，近地点（距地心 < 5e4 km）
%
% 作者：张晨
% 邮箱：chenzhang@csu.ac.cn
% 单位：中国科学院空间应用工程与技术中心，空间探索室
% 时间：2021年10月01日
%%%%%%%%%%%%%%%%%%%%%%%%

% ---------------- 载入参数 ----------------
miu =0.01215;

l_star = 384400;

norh=aux.periOrb_xx;
%% --------------- 卫星加速度 ---------------


% 远P1点条件
   distance_from_target1 = norm([x(1), x(2), x(3)] - [-miu, 0, 0]);  
% 和P1距离条件（3 - 5倍地月距）
   distance_from_target2 = norm([x(1), x(2), x(3)] - [1-miu, 0, 0]);  

distances = sqrt(sum((norh(:,1:3) - [x(1), x(2), x(3)]).^2, 2));  % 计算每一行与点 a 的距离
   distance_from_target3=min(distances);
%% --------------- 满足所有约束条件 ---------------
 if distance_from_target1 - 0.02<0|| distance_from_target2-0.0050<0|| distance_from_target3-0.000010<0
    % 仅在距离小于0.5时触发  
    value = 0;
    else 
        value=1;
    end

% isterminal = 0; % 是否执行积分终止条件(多次)
isterminal = 1; % 是否执行积分终止条件(单次)

direction = 0; % 积分终止方向，由正向负或者由负向正

end
