close all;
clear;
 global aux bei0 tn
global lb ub 
global closeApproaches t0 
tn=0;
closeApproaches =0;
t0=0;miu=0.01215;
%aux = get_NRHO();plot3(1-miu,0,0,'*');
t_star=4.3438*24*3600;
node=20;
datan=[];
ay=[-0.029232371309394;-0.009639910994709;-0.003907007353727;-5.166476753176707;7.775970576549712;3.403118755590977];
    dataMatrix= load('seccond.txt');
yy=dataMatrix(45,:);

   options = odeset('RelTol' , 1e-12 , 'AbsTol' , 1e-12 ,'Events', @eventFunction);
axis equal; % 
%ay=[0.05,0,0,0,2,0];%yy(1,7:12)
      [seg_tt , seg_xx] = ode113(@vdp2 , [-31.7880341270722,-7.11401665908105,] ,ay , options );
hold on;plot3(seg_xx(:,1),seg_xx(:,2),seg_xx(:,3));plot3(-miu,0,0,'*');view(45,45);%aux = get_NRHO();
%%约束计
disp(['近月次数: ', num2str(closeApproaches)]);
function [value, isterminal, direction] = eventFunction(t, x)  
global closeApproaches t0 tn
    miu = 0.01215;  
    distance_from_target1 = norm([x(1), x(2), x(3)] - [-miu, 0, 0]);  
    distance_from_target2 = norm([x(1), x(2), x(3)] - [1-miu, 0, 0]);  
    if distance_from_target1 - 0.016<0|| distance_from_target2-0.0047<0
    % 仅在距离小于0.5时触发  
    value = 0;
    else 
        value=1;
    end



    if distance_from_target1 - 0.1<0
        if tn==0
            tn=t;
        else
        if abs(t-tn)>1

    % 仅在距离小于0.5时触发  
    value = 0;
    else 
        value=1;
        end
        end
    end



        if  distance_from_target2-0.1721<0
if t0==0
t0=t;
   closeApproaches = closeApproaches + 1; % 增加计数器
else
    if abs(t-t0)>2
        t0=t;
           closeApproaches = closeApproaches + 1; % 增加计数器
    end
end
        end
    isterminal = 1; % 终止积分  
    direction = 0; % 在任何方向都检测  
    end
     
   function result=vdp1(t,x)

u=0.01215;
R=389.1723985;%太阳转动半径（km）
ws = -0.925195985520347;%太阳转动频率
theta=ws*t;
m_s0=1.989e30;%太阳质量
m1=5.965e24;%地球质量
m2=7.342e22;%月球质量
m_s=m_s0/(m1+m2);
r=[x(1);x(2);x(3)];re=[-u;0;0];rm=[1-u;0;0];
r1=norm(r-re);r2=norm(r-rm);
r3=sqrt((x(1)-R*cos(theta))^2+(x(2)-R*sin(theta))^2+x(3)^2);
a_sx=-m_s*(x(1)-R*cos(theta))/(r3)^3-m_s*cos(theta)/R^2;
a_sy=-m_s*(x(2)-R*sin(theta))/(r3)^3-m_s*sin(theta)/R^2;
a_sz=-m_s*x(3)/(r3)^3;

   r1_squared = r1^2;   
    r2_squared = r2^2;   
    r3_squared = r3^2;
 
    r1_cubed = r1_squared^(3/2);  
    r2_cubed = r2_squared^(3/2);  
    r3_cubed = r3_squared^(3/2);
 
    r1_fifth = r1_squared^(5/2);  
    r2_fifth = r2_squared^(5/2); 
    r3_fifth = r3_squared^(5/2);
    % 计算 U 系数  
    mu=u;
    Uxx=(mu - 1) / r1_cubed - mu / r2_cubed -m_s/r3_cubed +...
        (3*(u + x(1))^2*(1 - u))/(r1_fifth) +...
        (3*m_s*(x(1) - R*cos(theta))^2)/r3_fifth +...
        (3*u*(u + x(1) - 1)^2)/r2_fifth + 1;
 
    Uxy=(3*m_s*(x(1)-R*cos(theta))*(x(2)-R*sin(theta)))/r3_fifth+...
        (3*x(2)*(u + x(1))*(1-u))/r1_fifth +...
        (3*u*x(2)*(u + x(1) - 1))/r2_fifth;
 
    Uxz=(3*u*x(3)*(u + x(1) - 1))/r2_fifth +...
        (3*x(3)*(u + x(1))*(1 - u))/r1_fifth + ...
        (3*m_s*x(3)*(x(1) - R*cos(theta)))/r3_fifth; 
 
    Uyy=(u - 1)/r1_cubed-u/r2_cubed-m_s/r3_cubed +...
        (3*x(2)^2*(1 - u))/r1_fifth + (3*u*x(2)^2)/r2_fifth...
        + (3*m_s*(x(2)- R*sin(theta))^2)/r3_fifth + 1;
 
    Uyz=(3*m_s*x(3)*(x(2)-R*sin(theta)))/r3_fifth+...
        (3*x(2)*x(3)*(1 - u))/r1_fifth +...
        (3*u*x(2)*x(3))/r2_fifth;  
 
    Uzz= (u - 1)/r1_cubed- u/r2_cubed -m_s/r3_cubed+...
        (3*x(3)^2 * (1 - u)) / r1_fifth + ...  
        (3*u*x(3)^2) / r2_fifth+(3*m_s*x(3)^2)/r3_fifth;
     Xp = reshape(x(7:end), 6, 6);
         K = [0, 0, 0, 1, 0, 0;   
         0, 0, 0, 0, 1, 0;   
         0, 0, 0, 0, 0, 1;   
         Uxx, Uxy, Uxz, 0, 2, 0;   
         Uxy, Uyy, Uyz, -2, 0, 0;   
         Uxz, Uyz, Uzz, 0, 0, 0];  
    dXpdt = reshape(K * Xp, [], 1);
xx=x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3+a_sx;
yy=x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3+a_sy;
zz=-(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3+a_sz;
result=[x(4);x(5);x(6);xx;yy;zz;dXpdt];
   end

function [ceqNum , ceq , Gceq] = yueshu(tau_k , xx_tauk , var_tauk , ...
    tau_kp1 , xx_taukp1 , var_taukp1 , ...
    xx_taukp1_ , phi_tauk_taukp1 , nVar , nNode , jLoop )
%
% 构造状态连接约束
%
% 注意：
% 如果xxkp1是'dv'，则约束为r1f - r20
% 否则都为x1f - x20
%
% 作者：张晨
% 邮箱：chenzhang@csu.ac.cn
% 单位：中国科学院空间应用工程与技术中心，空间探索室
% 时间：2021年08月25日
%%%%%%%%%%%%%%%%%%%%%%%%

% ---------------------------------------------------------------------------
% tauk动力学
dxx_tauk =vdp2(tau_k , xx_tauk );

% taukp1_动力学
dxx_taukp1_ =vdp2(tau_kp1 , xx_taukp1_ );

% 模块
dtauj_dtau1 = 1 - (jLoop - 1) / (nNode - 1);
dtaujp1_dtau1 = 1 - jLoop / (nNode - 1);
dtauj_dtaun = (jLoop - 1) / (nNode - 1);
dtaujp1_dtaun = jLoop / (nNode - 1);

% ---------------------------------------------------------------------------
% 连接约束数
ceqNum =6;

% 约束
ceq = (xx_taukp1_ - xx_taukp1);

% 梯度预分配
Gceq = zeros(6 , nVar);

% --------------- 状态连接约束（梯度） -------------
% wrt xx_tauk
if jLoop == 1

    Gceq(:, 6 * (jLoop - 1) + 1 : 6 * jLoop) = phi_tauk_taukp1  * dxde_leo(var_tauk );

else

    Gceq(: ,6 * (jLoop - 1) + 1 : 6 * jLoop) = phi_tauk_taukp1;

end



    Gceq(: , 6* jLoop + 1 :6 * (jLoop + 1)) = - eye(6);



% 状态连接约束 wrt tau_1
Gceq(: , 6 * nNode + 1) = - phi_tauk_taukp1 * dxx_tauk * dtauj_dtau1 + dxx_taukp1_ * dtaujp1_dtau1;

% 状态连接约束 wrt tau_n
Gceq(: , 6 * nNode + 2) = - phi_tauk_taukp1 * dxx_tauk * dtauj_dtaun + dxx_taukp1_ * dtaujp1_dtaun;

end
function result=vdp2(t,x)

u=0.01215;
R=389.1723985;%太阳转动半径（km）
ws = -0.925195985520347;%太阳转动频率
theta=ws*t;
m_s0=1.989e30;%太阳质量
m1=5.965e24;%地球质量
m2=7.342e22;%月球质量
m_s=m_s0/(m1+m2);
r=[x(1);x(2);x(3)];re=[-u;0;0];rm=[1-u;0;0];
r1=norm(r-re);r2=norm(r-rm);
r3=sqrt((x(1)-R*cos(theta))^2+(x(2)-R*sin(theta))^2+x(3)^2);
a_sx=-m_s*(x(1)-R*cos(theta))/(r3)^3-m_s*cos(theta)/R^2;
a_sy=-m_s*(x(2)-R*sin(theta))/(r3)^3-m_s*sin(theta)/R^2;
a_sz=-m_s*x(3)/(r3)^3;
xx=x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3+a_sx;
yy=x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3+a_sy;
zz=-(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3+a_sz;
result=[x(4);x(5);x(6);xx;yy;zz];
end