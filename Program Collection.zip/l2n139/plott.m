%%

clear;
close all;

options = odeset('RelTol',1e-12,'AbsTol',1e-12);
 aux.periOrb_xi=[1.013420511950753;8.748592600000000e-27;0.175374332135966;1.797598400000000e-15;-0.083726106421253;-6.474513900000000e-17];
 
 
 
 
 [periOrb_tt , periOrb_xx] = ode113(@vdp2, [0 , 1.5708] , aux.periOrb_xi , options );
aux.periOrb_tt = periOrb_tt;
aux.periOrb_xx = periOrb_xx;

% % 【测试】
%figure(1);
 plot3(periOrb_xx(:,1) , periOrb_xx(:,2) ,periOrb_xx(:,3) );
 axis equal;hold on;
 plot3(1-0.01215,0,0,'*');plot3(-0.01215,0,0,'*');