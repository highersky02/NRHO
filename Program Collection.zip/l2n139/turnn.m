%%%旋转系转轨道根数程序
function var =turnn(xf )
miu=0.01215;
p1=1;t1=0;

for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xf(pp1,1),xf(pp1,2),xf(pp1,4),xf(pp1,5)]';
xat1=[];
xat1=(R1)*(xroa1-da1);
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
b=[zz1(3,1),zz1(4,1),xf(1,6)];
a=[zz1(1,1),zz1(2,1),xf(1,3)];



r=a;
v=b;
H=cross(r,v);
i=acos(H(3)/norm(H));
N = cross([0 0 1],H);
n = norm(N);
%...Equation 4.9:
if n~= 0
    RA = acos(N(1)/n);
    if N(2) < 0
        RA = 2*pi - RA;
    end
else
    RA = 0;
end
b2=v;
r1=norm(r);r2=[r1*cos(RA),r1*sin(RA),0];
a2=r;
vv=sqrt((1-miu)/(r1));
vc=vv;
Aa=cross(a,b);
ia=Aa/norm(Aa);
Ba=cross(ia,a);
ib=Ba/norm(Ba);
vca=vc*ib;bei=norm(v)/norm(vca);

acos(dot(ib,v)/(norm(ib)*norm(v)));

if r(3)<0
    

cita=-acos(dot(r,r2)/norm(r)/norm(r2));
else 
    cita=acos(dot(r,r2)/norm(r)/norm(r2));
end
ou=RA;rp=norm(r);

  var = [r1;
       cita ;
       ou;
        i;
        bei;
        0];
end
