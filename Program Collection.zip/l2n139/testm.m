

%%test

clear;clc;
miu=0.01215;



xaf=[-0.0155929549839808,-0.0194208233672628,-0.00331360039877746,-9.66008843263158,1.38971930742391,1.88174050422116];

zx=abs(candi_LEO2DRObb(:,17))+candi_LEO2DRObb(:,18);
zx_filtered = zx(zx >= 2.8);  
%[min_value, min_index] = min(zx_filtered);  
[min_value, min_index] = min(abs(zx-2.808)); 
%io=turnn2(xaf)'
%ro=turrn(io)'