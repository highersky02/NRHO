function dydt=CRBP(t,x)
%%三体系统下的状态转移矩阵积分程序；
global xx zz yy
  u = 0.01215;
  mu=u;
%3.04036e-6;%0.0000779;%%%
r=[x(1);x(2);x(3)];re=[-u;0;0];rm=[1-u;0;0];
r1=norm(r-re);r2=norm(r-rm);
    mu_x1 = mu + x(1);              % 方便计算  
    mu_x1_minus_1 = mu_x1 - 1;       % mu + x(1,i) - 1  
    r1_squared = r1^2;   
    r2_squared = r2^2;   
    
    r1_cubed = r1_squared^(3/2);  
    r2_cubed = r2_squared^(3/2);  
    
    r1_fifth = r1_squared^(5/2);  
    r2_fifth = r2_squared^(5/2);  
    
    % 计算 U 系数  
    Uxx= (mu - 1) / r1_cubed - mu / r2_cubed + ...  
        (3*mu*(2*mu + 2*x(1) - 2) * (mu_x1_minus_1)) / (2 * r2_fifth) - ...  
        ((6*mu + 6*x(1)) * mu_x1 * (mu - 1)) / (2 * r1_fifth) + 1;  

    Uxy= (3*mu*x(2) * (mu_x1_minus_1)) / r2_fifth - ...  
        (3*x(2) * mu_x1 * (mu - 1)) / r1_fifth;  

    Uxz= (3*mu*x(3) * (mu_x1_minus_1)) / r2_fifth - ...  
        (3*x(3) * mu_x1 * (mu - 1)) / r1_fifth;  

    Uyy= (mu - 1) / r1_cubed - mu / r2_cubed - ...  
        (3*x(2)^2 * (mu - 1)) / r1_fifth + ...  
        (3*mu*x(2)^2) / r2_fifth + 1;  

    Uyz= (3*mu*x(2)*x(3)) / r2_fifth - ...  
        (3*x(2)*x(3) * (mu - 1)) / r1_fifth;  

    Uzz= (mu - 1) / r1_cubed - mu / r2_cubed - ...  
        (3*x(3)^2 * (mu - 1)) / r1_fifth + ...  
        (3*mu*x(3)^2) / r2_fifth;
        K = [0, 0, 0, 1, 0, 0;   
         0, 0, 0, 0, 1, 0;   
         0, 0, 0, 0, 0, 1;   
         Uxx, Uxy, Uxz, 0, 2, 0;   
         Uxy, Uyy, Uyz, -2, 0, 0;   
         Uxz, Uyz, Uzz, 0, 0, 0];  
    Xp = reshape(x(7:end), 6, 6);
    dXpdt = reshape(K * Xp, [], 1);
dydt=[x(4);...
     x(5);...
     x(6);...
     x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3;...
     x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3;...
     -(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3;...
      dXpdt ];
xx=x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3;
zz=-(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3;
yy= x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3;
end