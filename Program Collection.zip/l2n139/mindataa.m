mindata=[candi_LEO2DROaa;candi_LEO2DRObb;candi_LEO2DROcc;candi_LEO2DROdd];
maindata=[];j=1;miandata=[];
for i=1:length(mindata)
    if mindata(i,19)<3e-5&&mindata(i,18)<3
        miandata(j,1:19)=mindata(i,:);
         miandata(j,17)=abs(mindata(i,17));
         miandata(j,20)=abs(mindata(i,17))+mindata(i,18);
        j=j+1;
    end
    
end



save maindata