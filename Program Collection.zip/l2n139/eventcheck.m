
clc;
close all;
clear;
miu=0.01215;
% 定义全局变量以跟踪近月次数  
global closeApproaches t0
t0=0;
closeApproaches = 0; % 初始化计数器 
xa=[1.013420512;8.7485926e-27;0.195374332;1.7975984e-15;-0.0937261;-6.474514e-17];
tf=1.3953*5;
 options = odeset('RelTol' , 1e-12 , 'AbsTol' , 1e-12 ,'Events', @eventFunction);
[t, xpp] = ode45(@ vdp2, [0, tf], xa,options );hold on;
plot3(xpp(:,1),xpp(:,2),xpp(:,3));view(45,45);axis equal;
plot3(1-miu,0,0,'*');

function Loc=vdp2(t,x)
global xx zz yy u
u= 0.01215;
r=[x(1);x(2);x(3)];re=[-u;0;0];rm=[1-u;0;0];
r1=norm(r-re);r2=norm(r-rm);
Loc=[x(4);...
     x(5);...
     x(6);...
     x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3;...
     x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3;...
     -(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3];
xx=x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3;
yy= x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3;
zz=-(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3;
end
function [value, isterminal, direction] = eventFunction(t, x)  
global closeApproaches t0
    miu = 0.01215;  
    distance_from_target1 = norm([x(1), x(2), x(3)] - [-miu, 0, 0]);  
    distance_from_target2 = norm([x(1), x(2), x(3)] - [1-miu, 0, 0]);  
    if distance_from_target1 - 0.016<0|| distance_from_target2-0.0047<0
    % 仅在距离小于0.5时触发  
    value = 0;
    else 
        value=1;
    end
    
       if  distance_from_target2-0.05<0
if t0==0
t0=t;
   closeApproaches = closeApproaches + 1; % 增加计数器
else
    if t-t0>1
        t0=t
           closeApproaches = closeApproaches + 1; % 增加计数器
    end
end
    % 仅在距离小于0.5时触发  
   
    end
    
 
   
    isterminal = 1; % 终止积分  
    direction = 0; % 在任何方向都检测  
end



% 在主程序中调用 ODE 求解器  
% 例如：  
% options = odeset('RelTol', 1e-12, 'AbsTol', 1e-12, 'Events', @eventFunction);  
% [t, x] = ode45(@odeFunction, tspan, x0, options);  

% 在求解完成后，输出近月次数  
disp(['近月次数: ', num2str(closeApproaches)]);