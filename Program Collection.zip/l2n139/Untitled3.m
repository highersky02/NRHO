%%%%引力辅助优化程序,混合引力辅助
clear;
close all;
clc;
outputFolder = 'E:\matlab study'; % 替换为您的指定路径  
% 确保文件夹存在，如果不存在则创建  
if ~exist(outputFolder, 'dir')  
    mkdir(outputFolder);  
end  
% 设置要保存所有文件内容的汇总文件名  
summaryFileName = 'summary_output.txt'; % 汇总文件名  
summaryFilePath = fullfile(outputFolder, summaryFileName);  

% 打开汇总文件准备写入  
fidsummary = fopen(summaryFilePath, 'w'); 

for jk=1:1
    outerFileName = sprintf('jk_%d.txt', jk);  
    outerFilePath = fullfile(outputFolder, outerFileName);  
    fidOuter = fopen(outerFilePath, 'w');  % 创建外层循环对应的 txt 文件 
for jj=1:1
   for jm=1:1

global aux  lb ub
aux = get_NRHO();
options = optimoptions('gamultiobj', ...  
        'PopulationSize',10, ...        % 种群大小  
        'MaxGenerations',10, ...        % 最大世代数  
        'Display', 'iter', ...            % 显示每代信息  
        'PlotFcn', {@gaplotpareto}, ...   % 绘制 Pareto 前沿  
        'FunctionTolerance', 1e-10, ...    % 目标函数容忍度  
        'SelectionFcn', 'selectiontournament'); % 设置选择方式为竞标赛模式% 函数容差  %出发时间2024.10.28.12
% 变量的下界和上界 

ub = [0,0.05*jk, 1.2, 1.2,1.2,5+0.2*jm];      % 上界  
lb = [0,0.05*(jk-1), -1.2,-1.2,-1.2,5+0.2*(jm-1)];  % 下界
%ub = [0,0.1, 1.2, 1.2,1.2,5.4];      % 上界  
%lb = [0,0, -1.2,-1.2,-1.2,];  % 下界
t_star=4.3438*24*3600;

[xx, fval] = gamultiobj(@VsumObjective, 6, [], [], [], [], lb, ub, @myNonlinearConstraints, options);
%xx=ffmincon(x);
%x=ffmincon(xx);
VDSUM =fval(:,1) ; % 计算每个点的距离  
[minDist2, minIndex2] = min(VDSUM);
  x=xx(minIndex2,:);
   miu=0.01215;
    t_star=4.3438*24*3600;
    tauf =x(1) / -0.925195985520347;
        sigma = x(2);
    % dro入轨点状态 (LU , VU)
    periOrb_x = interp1(aux.periOrb_tt , aux.periOrb_xx , sigma * aux.periOrb_P , 'spline')';
    x_nrho = periOrb_x(1,1);
    y_nrho = periOrb_x(2,1);
    z_nrho = periOrb_x(3,1);
    vx_nrho = periOrb_x(4,1);
    vy_nrho = periOrb_x(5,1);
    vz_nrho = periOrb_x(6,1);
target_point = [-miu, 0, 0]; 
    % 计算卫星入轨状态
    xx_rot = [x_nrho ;y_nrho ;z_nrho;vx_nrho+x(3);vy_nrho+x(4);vz_nrho+x(5)];
 options = odeset('RelTol' , 1e-10 , 'AbsTol' , 1e-10 ,'Events', @eventFunction);
 [t,xa] = ode45(@vdp2,  [tauf , tauf - x(6) * 86400 / t_star] ,  xx_rot,options );
 hold on;
%figure();
aux = get_NRHO();%plot3(1-miu,0,0,'k*');hold on;
   dvee=dve2(xx_rot, [tauf , tauf - x(6) * 86400 / t_star] );
 distances = sqrt(sum((xa(:, 1:3) - target_point).^2, 2)); % 计算每个点的距离  
     
  [minDist, minIndex] = min(distances);
  
%plot3(xa(:,1),xa(:,2),xa(:,3));hold on;plot3(xa(1,1),xa(1,2),xa(1,3),'+');hold on;
%plot3(-miu,0,0,'*');plot3(xa( minIndex,1),xa( minIndex,2),xa( minIndex,3),'+');hold on;
%filename = sprintf('figure_i%d_j%d.png', jk, jm);
%saveas(gcf, ['E:\matlab study\pic',filename]);
%%
savea(jm,:)=[xx_rot',tauf , t(minIndex),xa(minIndex,:),minDist, fval(minIndex2,:),x];

   end
    filename = sprintf('_jk%d_jj%d.txt', jk,jj);  % 创建文件名，例如 data_1.txt 
    %fullFilePath = fullfile(outputFolder, filename);  % 组合路径和文件名
    
    % 将文件名及数据写入汇总文件  
    fprintf(fidsummary, '文件名: %s\n', filename); % 写入文件名  
    fprintf(fidsummary, '内容:\n'); % 写入内容的标题  
    
    for row = 1:size(savea, 1) % 遍历数据的每一行  

        disp(savea(row, :));
        fprintf(fidsummary, '%13.9f\t', savea(row, :)); % 按行写入，以制表符分隔  
        fprintf(fidsummary, '\n'); % 每行结束后换行  
    end 
   % writematrix(savea, fid, 'Delimiter', 'tab'); % 将数据写入汇总文件，以制表符为分隔符  
    fprintf(fidsummary, '\n'); % 添加空行以分隔不同文件内容  
    fprintf(fidOuter, '_jj%d\n', jj);
    % 将文件名及数据写入jk控制下的文件  
    fprintf(fidOuter, '文件名: %s\n', filename); % 写入文件名  
    fprintf(fidOuter, '内容:\n'); % 写入内容的标题 
    for row1 = 1:size(savea, 1) % 遍历数据的每一行  

        disp(savea(row1, :));
        fprintf(fidOuter, '%13.9f\t', savea(row1, :)); % 按行写入，以制表符分隔  
        fprintf(fidOuter, '\n'); % 每行结束后换行  
    end 
fprintf(fidOuter, '\n'); % 添加空行以分隔不同文件内容  

end
   
  fclose(fidOuter);
end
fclose(fidsummary);
function [c, ceq] = myNonlinearConstraints(x)
   global aux
 miu=0.01215;
    t_star=4.3438*24*3600;
    tauf =x(1) / -0.925195985520347;
        sigma = x(2);
    % dro入轨点状态 (LU , VU)
    periOrb_x = interp1(aux.periOrb_tt , aux.periOrb_xx , sigma * aux.periOrb_P , 'spline')';
    x_nrho = periOrb_x(1,1);
    y_nrho = periOrb_x(2,1);
    z_nrho = periOrb_x(3,1);
    vx_nrho = periOrb_x(4,1);
    vy_nrho = periOrb_x(5,1);
    vz_nrho = periOrb_x(6,1);

    % 计算卫星入轨状态
    xx_rot = [x_nrho ;y_nrho ;z_nrho;vx_nrho+x(3);vy_nrho+x(4);vz_nrho+x(5)];
       target_point = [-miu, 0, 0]; 
  % 没有不等式约束  
         options = odeset('RelTol' , 1e-10 , 'AbsTol' , 1e-10 ,'Events', @eventFunction);
 [t,xa] = ode45(@vdp2,  [tauf , tauf - x(6) * 86400 / t_star] ,  xx_rot,options);

 distances = sqrt(sum((xa(:, 1:3) - target_point).^2, 2)); % 计算每个点的距离  
    
    ceq = []; % 获取最小距离 
   c =(min(distances)-0.1); 
   end  

function f = VsumObjective(x)  
    % 目标函数  
   % 目标函数  
   global aux 
    miu=0.01215;
    t_star=4.3438*24*3600;
    tauf =x(1) / -0.925195985520347;
        sigma = x(2);
    % dro入轨点状态 (LU , VU)
    periOrb_x = interp1(aux.periOrb_tt , aux.periOrb_xx , sigma * aux.periOrb_P , 'spline')';
    x_nrho = periOrb_x(1,1);
    y_nrho = periOrb_x(2,1);
    z_nrho = periOrb_x(3,1);
    vx_nrho = periOrb_x(4,1);
    vy_nrho = periOrb_x(5,1);
    vz_nrho = periOrb_x(6,1);

    % 计算卫星入轨状态
    xx_rot = [x_nrho ;y_nrho ;z_nrho;vx_nrho+x(3);vy_nrho+x(4);vz_nrho+x(5)];
       target_point = [-miu, 0, 0]; 
     options = odeset('RelTol' , 1e-10 , 'AbsTol' , 1e-10 ,'Events', @eventFunction);
 [t,xa] = ode45(@vdp2,  [tauf , tauf - x(6) * 86400 / t_star] ,  xx_rot,options);
dvee=dve(xx_rot, [tauf , tauf - x(6) * 86400 / t_star] );
 distances = sqrt(sum((xa(:, 1:3) - target_point).^2, 2)); % 计算每个点的距离  
      f(1) = 10*abs(min(distances)-0.02); % 获取最小距离 
    % 返回最小距离  
   f(2)= norm([x(3),x(4),x(5)])+dvee; % 获取最小距离 
   
    % 返回最小距离  

end




function [value, isterminal, direction] = eventFunction(t, x)  
    miu = 0.01215;  
    distance_from_target1 = norm([x(1), x(2), x(3)] - [-miu, 0, 0]);  
    distance_from_target2 = norm([x(1), x(2), x(3)] - [1-miu, 0, 0]);  
    if distance_from_target1 - 0.018<0|| distance_from_target2-0.0057<0
    % 仅在距离小于0.5时触发  
    value = 0;
    else 
        value=1;
    end
    isterminal = 1; % 终止积分  
    direction = 0; % 在任何方向都检测  
    end

function [t,y]=result(x)


end

function dv=dve(x1,tt)
miu=0.01215;                

 options = odeset('RelTol' , 1e-10 , 'AbsTol' , 1e-10 ,'Events', @eventFunction);
[ta2, xa2] = ode45(@(t, y) vdp2(t, y), [tt(1),tt(2)], x1,options);%15386831.7932505

%plot3(-miu,0,0,'b+');hold on;hold on;plot3(xa2(1,1),xa2(1,2),xa2(1,3),'k*');hold on;plot3(xa2(:,1),xa2(:,2),xa2(:,3),'b');
%plot(xa2(:,1),xa2(:,2));hold on;
at= xa2(:,1:3)-[-miu,0,0];  
squared_sums = sqrt(sum(at.^2, 2)); % 计算每一行的平方和  

% 找到最小平方和的值及对应的行索引  
[min_value, min_index] = min(squared_sums);  
% 找到最小值的索引  


xf=xa2(min_index,1:6);
xaaf=xa2(min_index,1:6)';
hold on;
%plot3(xf(1,1),xf(1,2),xf(1,3),'g*')

%%
r=min_value;vv=sqrt((1-miu)/(r));%v=sqrt(mu2/(Rr));

%plot(xa(:,1),xa(:,2));hold on;
p1=1;t1=0;
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xf(pp1,1),xf(pp1,2),xf(pp1,4),xf(pp1,5)]';
xat1=[];
xat1=(R1)*(xroa1-da1);
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
b=[zz1(3,1),zz1(4,1),xf(1,6)];
a=[zz1(1,1),zz1(2,1),xf(1,3)];
vc=vv;
Aa=cross(a,b);
ia=Aa/norm(Aa);
Ba=cross(ia,a);
ib=Ba/norm(Ba);
vca=vc*ib;

dv=norm(b-vca);
end
function dv=dve2(x1,tt)
miu=0.01215;                

 options = odeset('RelTol' , 1e-10 , 'AbsTol' , 1e-10 ,'Events', @eventFunction);


[ta2, xa2] = ode45(@(t, y) vdp2(t, y), [tt(1),tt(2)], x1,options);%15386831.7932505

%plot3(-miu,0,0,'b+');hold on;hold on;plot3(xa2(1,1),xa2(1,2),xa2(1,3),'k*');hold on;
%plot3(xa2(:,1),xa2(:,2),xa2(:,3),'r');
%plot(xa2(:,1),xa2(:,2));hold on;
at= xa2(:,1:3)-[-miu,0,0];  
squared_sums = sqrt(sum(at.^2, 2)); % 计算每一行的平方和  

% 找到最小平方和的值及对应的行索引  
[min_value, min_index] = min(squared_sums);  
% 找到最小值的索引  


xf=xa2(min_index,1:6);
xaaf=xa2(min_index,1:6)';
hold on;
%plot3(xf(1,1),xf(1,2),xf(1,3),'g*')

%%
r=min_value;vv=sqrt((1-miu)/(r));%v=sqrt(mu2/(Rr));

%plot(xa(:,1),xa(:,2));hold on;
p1=1;t1=0;
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xf(pp1,1),xf(pp1,2),xf(pp1,4),xf(pp1,5)]';
xat1=[];
xat1=(R1)*(xroa1-da1);
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
b=[zz1(3,1),zz1(4,1),xf(1,6)];
a=[zz1(1,1),zz1(2,1),xf(1,3)];
vc=vv;
Aa=cross(a,b);
ia=Aa/norm(Aa);
Ba=cross(ia,a);
ib=Ba/norm(Ba);
vca=vc*ib;

dv=norm(b-vca);
p1=1;t1=0;%-theta;
xa3=[a,vca];

zz1=[];
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xa3(pp1,1),xa3(pp1,2),xa3(pp1,4),xa3(pp1,5)]';
xat1=[];
xat1=inv(R1)*(xroa1)+da1;
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
%plot(zz1(1,1),zz1(2,1),'y*');
zz2=[zz1(1,1),zz1(2,1),xa3(1,3),zz1(3,1),zz1(4,1),xa3(1,6)];
[ta4, xa4] = ode45(@(t, y) vdp2(t, y), [0,2*3.1415*r/vv], zz2);
%plot3(xa4(:,1),xa4(:,2),xa4(:,3));hold on;axis equal;  
axis equal;  

end

function Loc=vdp2(t,x)
global xx zz yy u
u= 0.01215;
r=[x(1);x(2);x(3)];re=[-u;0;0];rm=[1-u;0;0];
r1=norm(r-re);r2=norm(r-rm);
Loc=[x(4);...
     x(5);...
     x(6);...
     x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3;...
     x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3;...
     -(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3];
xx=x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3;
yy= x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3;
zz=-(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3;
end


function aux = get_NRHO()

% 初值,L2,北族T=1.5708的轨道
aux.periOrb_xi = [1.013420511950753;8.748592600000000e-27;0.175374332135966;1.797598400000000e-15;-0.083726106421253;-6.474513900000000e-17];
aux.periOrb_P = 1.5708;
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
% 积分

[periOrb_tt , periOrb_xx] = ode45(@vdp2, [0 , aux.periOrb_P] , aux.periOrb_xi , options );
aux.periOrb_tt = periOrb_tt;
aux.periOrb_xx = periOrb_xx;

% % 【测试】
%figure(1);
% plot3(periOrb_xx(:,1) , periOrb_xx(:,2) ,periOrb_xx(:,3) ,'r');
% Cr3bp_ScnEMRot(aux);

% DRO入轨脉冲 (VU)
aux.dvMag = 0.1;

end