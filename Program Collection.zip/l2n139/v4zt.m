function dydt=v4zt(t,x)
global xx yy zz mu;
mu = -0.01215;
u=mu;
m_s0=1.989e30;%太阳质量
m1=5.965e24;%地球质量
m2=7.342e22;%月球质量
m_s=m_s0/(m1+m2);
R=389.1723985;%太阳转动半径（km）
ws = -0.925195985520347;%太阳转动频率
theta=ws*t;
%3.04036e-6;%0.0000779;%%%
r=[x(1);x(2);x(3)];re=[-u;0;0];rm=[1-u;0;0];
r1=norm(r-re);r2=norm(r-rm);r3=sqrt((x(1)-R*cos(theta))^2+(x(2)-R*sin(theta))^2+x(3)^2);
a_sx=-m_s*(x(1)-R*cos(theta))/(r3)^3-m_s*cos(theta)/R^2;
a_sy=-m_s*(x(2)-R*sin(theta))/(r3)^3-m_s*sin(theta)/R^2;
a_sz=-m_s*x(3)/(r3)^3;
xx=x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3+a_sx;
yy=x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3+a_sy;
zz=-(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3+a_sz;
    r1_squared = r1^2;   
    r2_squared = r2^2;   
    r3_squared = r3^2;
 
    r1_cubed = r1_squared^(3/2);  
    r2_cubed = r2_squared^(3/2);  
    r3_cubed = r3_squared^(3/2);
 
    r1_fifth = r1_squared^(5/2);  
    r2_fifth = r2_squared^(5/2); 
    r3_fifth = r3_squared^(5/2);
    % 计算 U 系数  
    Uxx= (u - 1)/r1_cubed -u/r2_cubed -m_s/r3_cubed +...
        (3*(u + x(1))^2*(1 - u))/(r1_fifth) +...
        (3*m_s*(x(1) - R*cos(theta))^2)/r3_fifth +...
        (3*u*(u + x(1) - 1)^2)/r2_fifth + 1;
 
    Uxy=(3*m_s*(x(1)-R*cos(theta))*(x(2)-R*sin(theta)))/r3_fifth+...
        (3*x(2)*(u + x(1))*(1-u))/r1_fifth +...
        (3*u*x(2)*(u + x(1) - 1))/r2_fifth;
 
    Uxz=(3*u*x(3)*(u + x(1) - 1))/r2_fifth +...
        (3*x(3)*(u + x(1))*(1 - u))/r1_fifth + ...
        (3*m_s*x(3)*(x(1) - R*cos(theta)))/r3_fifth; 
 
    Uyy=(u - 1)/r1_cubed-u/r2_cubed-m_s/r3_cubed +...
        (3*x(2)^2*(1 - u))/r1_fifth + (3*u*x(2)^2)/r2_fifth...
        + (3*m_s*(x(2)- R*sin(theta))^2)/r3_fifth + 1;
 
    Uyz=(3*m_s*x(3)*(x(2)-R*sin(theta)))/r3_fifth+...
        (3*x(2)*x(3)*(1 - u))/r1_fifth +...
        (3*u*x(2)*x(3))/r2_fifth;  
 
    Uzz= (u - 1)/r1_cubed- u/r2_cubed -m_s/r3_cubed+...
        (3*x(3)^2 * (1 - u)) / r1_fifth + ...  
        (3*u*x(3)^2) / r2_fifth+(3*m_s*x(3)^2)/r3_fifth;
 
    K = [0, 0, 0, 1, 0, 0;   
         0, 0, 0, 0, 1, 0;   
         0, 0, 0, 0, 0, 1;   
         Uxx, Uxy, Uxz, 0, 2, 0;   
         Uxy, Uyy, Uyz, -2, 0, 0;   
         Uxz, Uyz, Uzz, 0, 0, 0];  
    Xp = reshape(x(7:end), 6, 6);
    dXpdt = reshape(K * Xp, [], 1);
dydt=[x(4);...
     x(5);...
     x(6);...
     xx;...
     yy;...
     zz;...
      dXpdt ];
 
end
