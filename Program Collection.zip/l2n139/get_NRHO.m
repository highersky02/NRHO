
function aux = get_NRHO()

% 初值,L2,北族T=1.5708的轨道
aux.periOrb_xi = [1.013420511950753;8.748592600000000e-27;0.175374332135966;1.797598400000000e-15;-0.083726106421253;-6.474513900000000e-17];
aux.periOrb_P = 1.3963;
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
% 积分

[periOrb_tt , periOrb_xx] = ode45(@vdp2, [0 , aux.periOrb_P] , aux.periOrb_xi , options );
aux.periOrb_tt = periOrb_tt;
aux.periOrb_xx = periOrb_xx;

% % 【测试】
%figure(1);
plot3(periOrb_xx(:,1) , periOrb_xx(:,2) ,periOrb_xx(:,3) ,'r');
% Cr3bp_ScnEMRot(aux);

% DRO入轨脉冲 (VU)
aux.dvMag = 0.1;

end