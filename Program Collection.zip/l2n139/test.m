


%%%%测时约束积分过程；
clear;
clc;miu=0.01215;

t_star=4.3438*24*3600;  options = odeset('RelTol' , 1e-8 , 'AbsTol' , 1e-8 ,'Events', @eventFunction);
x0=[3.060028374852793,0.460465387987533,0.025683275613443,0.009827103772928,0.024040569769220,120];
 xx_rot=[0.989268444454350;0.020643787631154;0.017696502117396;0.096388817871473;0.335917463090721;0.846473152777224];
 tauf=-3.307438016099668;
 [t,xa] = ode45(@vdp1,  [-3.307438016099668 , -3.307438016099668- 120* 86400 / t_star] ,  xx_rot,options );
 aux = get_NRHO();
 target_point = [-miu, 0, 0]; 
distances = sqrt(sum((xa(:, 1:3) - target_point).^2, 2)); % 计算每个点的距离  

 [minDist, minIndex] = min(distances);
plot3(-miu,0,0,'*');plot3(xa( minIndex,1),xa( minIndex,2),xa( minIndex,3),'+');hold on; plot3(xa(:,1),xa(:,2),xa(:,3));hold on;plot3(xa(1,1),xa(1,2),xa(1,3),'+');hold on;

    % 定义事件函数  
 
    function [value, isterminal, direction] = eventFunction(t, x)  
    miu = 0.01215;  
   
    distance_from_target = norm([x(1), x(2), x(3)] - [-miu, 0, 0]);   
 if   distance_from_target-0.5<0
     value=0;
 else
     value=1;
 end
    % 仅在距离小于0.5时触发  
 

    isterminal = 1; % 终止积分  
    direction = 0; % 在任何方向都检测  
    end
