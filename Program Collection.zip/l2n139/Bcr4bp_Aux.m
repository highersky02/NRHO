function aux = Bcr4bp_Aux()
%
% 载入双圆四体问题参数

EMRot.mu =0.01215 ;
EMRot.mus = 3.2939e+05;
EMRot.as=389.1723985;
EMRot.ws =-0.925195985520347;%太阳转动频率;
l_EM = 384747.992; % km
dim.EMRot_l = l_EM;

aux.dim = dim;
aux.EMRot = EMRot;
end