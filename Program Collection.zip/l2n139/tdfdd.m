close all;
clear;
yy=[1,1];


xaf=[-0.0274956910544634,	-0.0125798025460844	,-0.00250166623722896	,5.29414239115900	,-5.15879925210817	,-6.53388422620319];	
%%最优结果
xaf=[-0.0286094679533862	,-0.0113614283732341,	-6.21289893984337e-05	,-5.59809762303240,	8.11328406454508	,-0.592112396434935	];
xaf=[-0.0266666519822576,	-0.0137568128307377	,0.000130061393452559,	-6.77525001929124,	7.15417988777215,	0.497972910757160];
    tf=0.991048027488174;ts=-28.4957979041179	;
miu=0.01215;

     options = odeset('RelTol' , 1e-12 , 'AbsTol' , 1e-12 ,'Events', @eventFunction);
 [t,xa] = ode113(@vdp1,  [ts,tf] ,  xaf,options);
 hold on;ac=dve2(xaf,[ts,tf]);
 plot3(1-miu,0,0,'b*');aux = get_NRHO();
plot3(-miu,0,0,'r*');
plot3(xa(end,1),xa(end,2),xa(end,3),'r+');plot3(xa(:,1),xa(:,2),xa(:,3));
 view(45,45);


aux.periOrb_xi =[1.013420511950753;8.748592600000000e-27;0.175374332135966;1.797598400000000e-15;-0.083726106421253;-6.474513900000000e-17];
aux.periOrb_P =  1.39;

options = odeset('RelTol',1e-12,'AbsTol',1e-12);
% 积分

[periOrb_tt , periOrb_xx] = ode45(@vdp2, [0 , aux.periOrb_P] , aux.periOrb_xi , options );
aux.periOrb_tt = periOrb_tt;
aux.periOrb_xx = periOrb_xx;

% % 【测试】

plot3(periOrb_xx(:,1) , periOrb_xx(:,2) ,periOrb_xx(:,3) ,'r');hold on;
plot3(1-0.01215,0,0,'b*');
 function [value, isterminal, direction] = eventFunction(t, x)  
    miu = 0.01215;  
    distance_from_target1 = norm([x(1), x(2), x(3)] - [-miu, 0, 0]);  
    distance_from_target2 = norm([x(1), x(2), x(3)] - [1-miu, 0, 0]);  
    if distance_from_target1 - 0.017<0|| distance_from_target2-0.0057<0
    % 仅在距离小于0.5时触发  
    value = 0;
    else 
        value=1;
    end
    isterminal = 1; % 终止积分  
    direction = 0; % 在任何方向都检测  
end
 function result=vdp1(t,x)

u=0.01215;
R=389.1723985;%太阳转动半径（km）
ws = -0.925195985520347;%太阳转动频率
theta=ws*t;
m_s0=1.989e30;%太阳质量
m1=5.965e24;%地球质量
m2=7.342e22;%月球质量
m_s=m_s0/(m1+m2);
r=[x(1);x(2);x(3)];re=[-u;0;0];rm=[1-u;0;0];
r1=norm(r-re);r2=norm(r-rm);
r3=sqrt((x(1)-R*cos(theta))^2+(x(2)-R*sin(theta))^2+x(3)^2);
a_sx=-m_s*(x(1)-R*cos(theta))/(r3)^3-m_s*cos(theta)/R^2;
a_sy=-m_s*(x(2)-R*sin(theta))/(r3)^3-m_s*sin(theta)/R^2;
a_sz=-m_s*x(3)/(r3)^3;
xx=x(1)+2*x(5)-(1-u)*(x(1)+u)/(r1)^3-u*(x(1)-1+u)/(r2)^3+a_sx;
yy=x(2)-2*x(4)-(1-u)*x(2)/(r1)^3-u*x(2)/(r2)^3+a_sy;
zz=-(1-u)*x(3)/(r1)^3-u*x(3)/(r2)^3+a_sz;
result=[x(4);x(5);x(6);xx;yy;zz];
 end

 
 function dv=dve2(x1,tt)
miu=0.01215;                

 options = odeset('RelTol' , 1e-12, 'AbsTol' , 1e-12 ,'Events', @eventFunction);


[ta2, xa2] = ode45(@(t, y) vdp1(t, y), [tt(1),tt(2)], x1,options);%15386831.7932505

plot3(-miu,0,0,'b+');hold on;hold on;plot3(xa2(1,1),xa2(1,2),xa2(1,3),'k*');hold on;
plot3(xa2(:,1),xa2(:,2),xa2(:,3),'r');
%plot(xa2(:,1),xa2(:,2));hold on;
at= xa2(:,1:3)-[-miu,0,0];  
squared_sums = sqrt(sum(at.^2, 2)); % 计算每一行的平方和  

% 找到最小平方和的值及对应的行索引  
[min_value, min_index] = min(squared_sums);  
% 找到最小值的索引  


xf=xa2(min_index,1:6);
xaaf=xa2(min_index,1:6)';
hold on;
plot3(xf(1,1),xf(1,2),xf(1,3),'g*')

%%
r=min_value;vv=sqrt((1-miu)/(r));%v=sqrt(mu2/(Rr));

%plot(xa(:,1),xa(:,2));hold on;
p1=1;t1=0;
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xf(pp1,1),xf(pp1,2),xf(pp1,4),xf(pp1,5)]';
xat1=[];
xat1=(R1)*(xroa1-da1);
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
b=[zz1(3,1),zz1(4,1),xf(1,6)];
a=[zz1(1,1),zz1(2,1),xf(1,3)];
vc=vv;
Aa=cross(a,b);
ia=Aa/norm(Aa);
Ba=cross(ia,a);
ib=Ba/norm(Ba);
vca=vc*ib;

dv=norm(b-vca);
p1=1;t1=0;%-theta;
xa3=[a,vca];

zz1=[];
for pp1=1:p1 
R1=[cos(t1(pp1)),-sin(t1(pp1)),0,0;...
   sin(t1(pp1)),cos(t1(pp1)),0,0;...
   -sin(t1(pp1)),-cos(t1(pp1)),cos(t1(pp1)),-sin(t1(pp1));...
    cos(t1(pp1)),-sin(t1(pp1)),sin(t1(pp1)),cos(t1(pp1))];
da1=[-miu,0,0,0]';%[-miu,0,0,0]';
xroa1=[xa3(pp1,1),xa3(pp1,2),xa3(pp1,4),xa3(pp1,5)]';
xat1=[];
xat1=inv(R1)*(xroa1)+da1;
zz1(1,pp1)=xat1(1,1);%xrob1(1,1);
zz1(2,pp1)=xat1(2,1);%xrob1(2,1);
zz1(3,pp1)=xat1(3,1);%xrob1(3,1);
zz1(4,pp1)=xat1(4,1);%xrob1(4,1);
end
%plot(zz1(1,1),zz1(2,1),'y*');
zz2=[zz1(1,1),zz1(2,1),xa3(1,3),zz1(3,1),zz1(4,1),xa3(1,6)];
[ta4, xa4] = ode45(@(t, y) vdp1(t, y), [0,2*3.1415*r/vv], zz2);
plot3(xa4(:,1),xa4(:,2),xa4(:,3),'y');hold on;axis equal;  
axis equal;  

end