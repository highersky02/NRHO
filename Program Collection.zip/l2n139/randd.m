
function [tau0Vec , van] = randd( orbNum , dvBound , aux)

tau0Vec = zeros(orbNum , 1);
x0Mtx = zeros(orbNum ,6);
sigmaMtx = zeros(orbNum , 1);

%[0.644782338136336,0.117205430154714,-0.0453190956237215,0.0139418827184922,0.0203706266101737,110.627859300792]
for iLoop = 1 : orbNum

    % 随机太阳相位角
    thetas =unifrnd(0 , 2 * pi);
    tauf = thetas / -0.925195985520347;

    % 随机相位角和脉冲
   
    
miu=0.01215;
rp=unifrnd(0.0050 , 0.02);
i=unifrnd(0,3.14);
ou=unifrnd(0,2*3.14);
cita=unifrnd(0,2*3.14);
bei=unifrnd(1.1,5);

 rpa=[rp*(cos(cita)*cos(ou)-sin(cita)*sin(ou)*cos(i))-miu+1,rp*(cos(cita)*sin(ou)+sin(cita)*cos(ou)*cos(i)),rp*(sin(cita)*sin(i))]';
   vpa=(-bei*sqrt((miu)/rp)*[sin(cita)*cos(ou)+cos(cita)*sin(ou)*cos(i),sin(cita)*sin(ou)-cos(cita)*cos(ou)*cos(i),-cos(cita)*sin(i)]+rp*[cos(cita)*sin(ou)+sin(cita)*cos(ou)*cos(i),-cos(cita)*cos(ou)+sin(cita)*sin(ou)*cos(i),0])';   
 
van=[rpa;vpa];
        tau0Vec(iLoop , :) =thetas;

    
end
end