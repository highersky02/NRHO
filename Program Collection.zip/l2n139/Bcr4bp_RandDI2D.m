function [tau0Vec , x0Mtx , sigmaMtx,op] = Bcr4bp_RandDI2D( orbNum , dvBound , aux)

tau0Vec = zeros(orbNum , 1);
x0Mtx = zeros(orbNum ,6);
sigmaMtx = zeros(orbNum , 1);

%[0.644782338136336,0.117205430154714,-0.0453190956237215,0.0139418827184922,0.0203706266101737,110.627859300792]
for iLoop = 1 : orbNum

    % 随机太阳相位角
    thetas =unifrnd(0 , 2 * pi);
    tauf = thetas / -0.925195985520347;ob=1.5;
op1=unifrnd(-ob ,ob);
op2=unifrnd(-ob ,ob);
op3=unifrnd(-ob ,ob);
    % 随机相位角和脉冲
    sigma =unifrnd(0.45, 0.6);
op=[op1,op2,op3];
    % DRO入轨点脉冲 (VU)

    % dro入轨点状态 (LU , VU)
    periOrb_x = interp1(aux.periOrb_tt , aux.periOrb_xx , sigma * aux.periOrb_P , 'spline')';
    x_nrho = periOrb_x(1);
    y_nrho = periOrb_x(2);
    z_nrho = periOrb_x(3);
    vx_nrho = periOrb_x(4);
    vy_nrho = periOrb_x(5);
    vz_nrho = periOrb_x(6);

    % 计算卫星入轨状态
    xx_rot = [x_nrho ;...
        y_nrho ;
         z_nrho ;
        vx_nrho+op1;
        vy_nrho+op2;
         vz_nrho+op3];
    
    
        tau0Vec(iLoop , :) =thetas;
        x0Mtx(iLoop , :) = xx_rot;
        sigmaMtx(iLoop , :) = sigma;

    
end
end