%%%轨道根数转旋转系程序
function van =turrn(xv )

miu=0.01215;
rp=xv(1);
i=xv(4);
ou=xv(3);
cita=xv(2);
bei=xv(5);

 rpa=[rp*(cos(cita)*cos(ou)-sin(cita)*sin(ou)*cos(i))-miu,rp*(cos(cita)*sin(ou)+sin(cita)*cos(ou)*cos(i)),rp*(sin(cita)*sin(i))]';
   vpa=(-bei*sqrt((1-miu)/rp)*[sin(cita)*cos(ou)+cos(cita)*sin(ou)*cos(i),sin(cita)*sin(ou)-cos(cita)*cos(ou)*cos(i),-cos(cita)*sin(i)]+rp*[cos(cita)*sin(ou)+sin(cita)*cos(ou)*cos(i),-cos(cita)*cos(ou)+sin(cita)*sin(ou)*cos(i),0])';   
 
van=[rpa;vpa];
end