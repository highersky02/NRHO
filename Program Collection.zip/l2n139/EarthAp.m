
function [value, isterminal, direction] = EarthAp(tau , xx )
%
% 积分终止条件，EMRot，远地点（距地心 120e4 - 200e4 km）




xc = xx(1);
yc = xx(2);
zc=xx(3);


%% --------------- 卫星加速度 ---------------


% 远P1点条件
cons1 =norm([xc,yc,zc]-[-miu,0,0])-0.5<0;


%% --------------- 满足所有约束条件 ---------------
if cons1 
    
    value = 1;
    
else
    
    value = [];
    
end

% isterminal = 0; % 是否执行积分终止条件(多次)
isterminal = 1; % 是否执行积分终止条件(单次)

direction = 0; % 积分终止方向，由正向负或者由负向正

end
