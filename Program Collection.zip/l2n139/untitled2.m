



for i=1:length(candi_LEO2DRO2)
    candi_LEO2DRO2(i,13)=candi_LEO2DRO2(i,13)*1.3963/1.5708;
end
save   candi_LEO2DRO2