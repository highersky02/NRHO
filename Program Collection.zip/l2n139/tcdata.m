
i=1;datan4=[];
dantanss = load('datans.txt');
for ibm=1:(length(dantanss))
if dantanss(ibm,10)<1

if dantanss(ibm,7)<dantanss(ibm,8)
datan4(i,7:12)=dantanss(ibm,1:6);
datan4(i,13)=dantanss(ibm,9);
datan4(i,16)=dantanss(ibm,7);
datan4(i,15)=dantanss(ibm,8);
datan4(i,17)=dantanss(ibm,10);
datan4(i,18)=dantanss(ibm,11);
datan4(i,19)=0;
i=i+1;
end
end
end
datan4=[datan4;datan2];
save datan4
writematrix(datan4, 'datan4.txt'); % 将矩阵保存为 datan.txt  
