

data=load('Rchange.txt');
vdata(:,1)=data(:,1)*384400;vdata(:,2)=data(:,2)
writematrix(vdata,'RchangeA.txt')