clear;close all;

yy=supportb(10);