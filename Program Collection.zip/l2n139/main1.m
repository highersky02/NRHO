%第一步主程遍历随机搜索合适解程序

clc; clear; close all; clear path;


t_star=4.3438*24*3600;
aux = get_NRHO();
dvMag = aux.dvMag;
calNum = 1e4;
% 结果预分配

resultMtx = cell(calNum , 1);
for iLoop = 1 : calNum 
        
       [thetas , xxf , sigma,op] = Bcr4bp_RandDI2D( 1 , [dvMag , dvMag] , aux);
       
       tauf = thetas / -0.925195985520347;
           % -------------------------------- 步骤1：近月点 -> WSB --------------------------------
   
         options = odeset('RelTol' , 1e-12 , 'AbsTol' , 1e-12 , 'Events' , @Bcr4bp_EventEMRot2DEarthRp);
        [seg1_tt , seg1_xx ] = ode113(@vdp1, ...
            [tauf , tauf-150*86400 / t_star] , xxf , options );
       
        %plot3(seg1_xx(:,1),seg1_xx(:,2),seg1_xx(:,3));hold on;plot3(-0.01215,0,0,'*');

    %     % 【测试】
    %     plotOrb2D(seg1_xx , 'b' , 2)

    % -------------------------------- 步骤2：WSB -> 近地点 --------------------------------
 miu=0.01215;

   distance_from_target1 = norm([seg1_xx(end,1), seg1_xx(end,2), seg1_xx(end,3)] - [-miu,0, 0]);  
% 和P1距离条件（3 - 5倍地月距）
   distance_from_target2 = norm([seg1_xx(end,1), seg1_xx(end,2), seg1_xx(end,3)] - [1-miu, 0, 0]);  
if distance_from_target2-0.0057<0
    
    continue;
end
   if distance_from_target1 - 0.02>0
         continue;
end
%% --------------- 满足所有约束条件 ---------------
figure();plot3(seg1_xx(:,1),seg1_xx(:,2),seg1_xx(:,3));hold on;plot3(-0.01215,0,0,'*');plot3(1-0.01215,0,0,'*');
    % 没有近地点，跳出
 
disp('1');
    %     % 【测试】
    %     % 【EMRot轨道】
    %     Bcr4bp_ScnEMRot(seg1_tt(1) , aux);
    %     plotOrb2D(seg1_xx , 'b' , 2);
    %     plotOrb2D(seg2_xx , 'r' , 2);
    %
    %     % 【SB1Rot轨道】
    %     [tt1_SB1Rot , xx1_SB1Rot] = Bcr4bp_EMRot2SB1RotMtx2D(seg1_tt , seg1_xx , aux);
    %     [tt2_SB1Rot , xx2_SB1Rot] = Bcr4bp_EMRot2SB1RotMtx2D(seg2_tt , seg2_xx , aux);
    %     Bcr4bp_ScnSB1Rot(tt1_SB1Rot(1) , aux);
    %     plotOrb2D(xx1_SB1Rot , 'b' , 2);
    %     plotOrb2D(xx2_SB1Rot , 'r' , 2);

    % --------------------------- 保存转移轨道初值 ---------------------------
    tau0 = tauf;
    xx0 = xxf;
    resultMtx{iLoop} = [tauf , xx0 ,  seg1_xx(end,:) , sigma,op,thetas, seg1_tt(end)  ];

end



resultMtx(cellfun(@isempty , resultMtx)) = [];
candi_LEO2DRO = zeros(size(resultMtx , 1) , size(resultMtx{1} , 2));
for iLoop = 1 : size(resultMtx , 1)
    candi_LEO2DRO(iLoop , :) = resultMtx{iLoop};
end

save candi_LEO2DRO candi_LEO2DRO

fprintf('candi_DRO2LLO 计算完毕！ \n')
fprintf('轨道初值: %0.0f \n' , calNum)
fprintf('DRO反向积分至LEO轨道数: %0.0f \n' , size(candi_LEO2DRO , 1))
