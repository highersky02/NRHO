
clear;
%%
 syms x_nrho y_nrho  z_nrho vx_nrho vy_nrho vz_nrho dvMag
 XX1 = [x_nrho;
     y_nrho;
      z_nrho;
    vx_nrho + dvMag * vx_nrho / sqrt(vx_nrho^2 + vy_nrho^2+vz_nrho^2);
     vy_nrho + dvMag * vy_nrho / sqrt(vx_nrho^2 + vy_nrho^2+vz_nrho^2);
     vz_nrho + dvMag * vz_nrho / sqrt(vx_nrho^2 + vy_nrho^2+vz_nrho^2)];
aa=simplify(jacobian(XX1 , [ x_nrho y_nrho  z_nrho vx_nrho vy_nrho vz_nrho]));
ab=[0;0;0;vx_nrho/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(1/2);vy_nrho/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(1/2);vz_nrho/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(1/2)];
 
ac=[ 1, 0, 0,                                                                                                                         0,                                                                                                                         0,                                                                                                                         0;
 0, 1, 0,                                                                                                                         0,                                                                                                                         0,                                                                                                                         0;
0, 0, 1,                                                                                                                         0,                                                                                                                         0,                                                                                                                         0;
 0, 0, 0, ((vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2) + dvMag*vy_nrho^2 + dvMag*vz_nrho^2)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2),                                                        -(dvMag*vx_nrho*vy_nrho)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2),                                                        -(dvMag*vx_nrho*vz_nrho)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2);
 0, 0, 0,                                                        -(dvMag*vx_nrho*vy_nrho)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2), ((vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2) + dvMag*vx_nrho^2 + dvMag*vz_nrho^2)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2),                                                        -(dvMag*vy_nrho*vz_nrho)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2);
0, 0, 0,                                                        -(dvMag*vx_nrho*vz_nrho)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2),                                                        -(dvMag*vy_nrho*vz_nrho)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2), ((vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2) + dvMag*vx_nrho^2 + dvMag*vy_nrho^2)/(vx_nrho^2 + vy_nrho^2 + vz_nrho^2)^(3/2)];
 


 syms rp cita ou i bei  f miu
  rpa=[rp*(cos(cita)*cos(ou)-sin(cita)*sin(ou)*cos(i))-miu,rp*(cos(cita)*sin(ou)+sin(cita)*cos(ou)*cos(i)),rp*(sin(cita)*sin(i))]';
       vpa=(-bei*sqrt((1-miu)/rp)*[sin(cita)*cos(ou)+cos(cita)*sin(ou)*cos(i),sin(cita)*sin(ou)-cos(cita)*cos(ou)*cos(i),-cos(cita)*sin(i)]+rp*[cos(cita)*sin(ou)+sin(cita)*cos(ou)*cos(i),-cos(cita)*cos(ou)+sin(cita)*sin(ou)*cos(i),0])';
XX=[rpa;vpa];
     bb= simplify(jacobian(XX , [  rp cita ou i bei f]));
     
     ba=[cos(conj(cita))*cos(conj(ou)) - cos(conj(i))*sin(conj(cita))*sin(conj(ou)),-conj(rp)*(cos(conj(ou))*sin(conj(cita)) + cos(conj(cita))*cos(conj(i))*sin(conj(ou))),-conj(rp)*(cos(conj(cita))*sin(conj(ou)) + cos(conj(i))*cos(conj(ou))*sin(conj(cita))),sin(conj(cita))*sin(conj(i))*sin(conj(ou))*conj(rp),0,0;
        cos(conj(cita))*sin(conj(ou)) + cos(conj(i))*cos(conj(ou))*sin(conj(cita)),-conj(rp)*(sin(conj(cita))*sin(conj(ou)) - cos(conj(cita))*cos(conj(i))*cos(conj(ou))),conj(rp)*(cos(conj(cita))*cos(conj(ou)) - cos(conj(i))*sin(conj(cita))*sin(conj(ou))),-cos(conj(ou))*sin(conj(cita))*sin(conj(i))*conj(rp),0,0;
        sin(conj(cita))*sin(conj(i)),cos(conj(cita))*sin(conj(i))*conj(rp),0,cos(conj(i))*sin(conj(cita))*conj(rp),0,0;
       cos(conj(cita))*sin(conj(ou)) + cos(conj(i))*cos(conj(ou))*sin(conj(cita)) - (conj(bei)*(cos(conj(ou))*sin(conj(cita)) + cos(conj(cita))*cos(conj(i))*sin(conj(ou)))*(conj(miu) - 1))/(2*conj((-(miu - 1)/rp)^(1/2))*conj(rp)^2),- conj(rp)*(sin(conj(cita))*sin(conj(ou)) - cos(conj(cita))*cos(conj(i))*cos(conj(ou))) - conj((-(miu - 1)/rp)^(1/2))*conj(bei)*(cos(conj(cita))*cos(conj(ou)) - cos(conj(i))*sin(conj(cita))*sin(conj(ou))),conj(rp)*(cos(conj(cita))*cos(conj(ou)) - cos(conj(i))*sin(conj(cita))*sin(conj(ou))) + conj((-(miu - 1)/rp)^(1/2))*conj(bei)*(sin(conj(cita))*sin(conj(ou)) - cos(conj(cita))*cos(conj(i))*cos(conj(ou))),-sin(conj(i))*(cos(conj(ou))*sin(conj(cita))*conj(rp) - cos(conj(cita))*sin(conj(ou))*conj((-(miu - 1)/rp)^(1/2))*conj(bei)),-conj((-(miu - 1)/rp)^(1/2))*(cos(conj(ou))*sin(conj(cita)) + cos(conj(cita))*cos(conj(i))*sin(conj(ou))),0;
       cos(conj(i))*sin(conj(cita))*sin(conj(ou)) - cos(conj(cita))*cos(conj(ou)) - (conj(bei)*(sin(conj(cita))*sin(conj(ou)) - cos(conj(cita))*cos(conj(i))*cos(conj(ou)))*(conj(miu) - 1))/(2*conj((-(miu - 1)/rp)^(1/2))*conj(rp)^2),conj(rp)*(cos(conj(ou))*sin(conj(cita)) + cos(conj(cita))*cos(conj(i))*sin(conj(ou))) - conj((-(miu - 1)/rp)^(1/2))*conj(bei)*(cos(conj(cita))*sin(conj(ou)) + cos(conj(i))*cos(conj(ou))*sin(conj(cita))),conj(rp)*(cos(conj(cita))*sin(conj(ou)) + cos(conj(i))*cos(conj(ou))*sin(conj(cita))) - conj((-(miu - 1)/rp)^(1/2))*conj(bei)*(cos(conj(ou))*sin(conj(cita)) + cos(conj(cita))*cos(conj(i))*sin(conj(ou))),-sin(conj(i))*(sin(conj(cita))*sin(conj(ou))*conj(rp) + cos(conj(cita))*cos(conj(ou))*conj((-(miu - 1)/rp)^(1/2))*conj(bei)),-conj((-(miu - 1)/rp)^(1/2))*(sin(conj(cita))*sin(conj(ou)) - cos(conj(cita))*cos(conj(i))*cos(conj(ou))),0;
       (cos(conj(cita))*sin(conj(i))*conj(bei)*(conj(miu) - 1))/(2*conj((-(miu - 1)/rp)^(1/2))*conj(rp)^2),-sin(conj(cita))*sin(conj(i))*conj((-(miu - 1)/rp)^(1/2))*conj(bei),0,cos(conj(cita))*cos(conj(i))*conj((-(miu - 1)/rp)^(1/2))*conj(bei),cos(conj(cita))*sin(conj(i))*conj((-(miu - 1)/rp)^(1/2)),0;];



 
 dd=[1,1,1;
     1,1,1;]

 
 syms x y z miu
 zx=sqrt((x+miu)^2+y^2+z^2)-1;

     bb= simplify(jacobian(zx , [  x y z]));
